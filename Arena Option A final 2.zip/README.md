# MORA HOME

A responsive, English-language B2B homeware catalogue built with React 19, Vite, Tailwind CSS v4 and React Router. The website intentionally has no public prices, cart or checkout.

## Routes

| Route | Purpose |
| --- | --- |
| `/` | Brand homepage, collections, artisan story, gifting and contact |
| `/products` | Searchable, sortable catalogue with category, material, use and order-type filters |
| `/products?category=pooja-products` | Shareable category-filtered collection |
| `/products/:slug` | Product information, thumbnails, zoom, fullscreen lightbox and enquiry |
| `/admin-login` | Unlinked private workspace entry point |

`src/App.tsx` is the application entry point. The layout, branding and lead forms live in `src/components`. Pages live in `src/pages`. Product and lead state, persistence and API calls live in `src/lib/store.tsx`.

## Preview Mode

With `VITE_API_BASE` unset, the application runs as a functional browser-local preview. Product creation, editing, publishing, hiding, deleting, image upload/reordering, enquiry management and CSV exports use localStorage. Updates appear immediately in the same browser and are synchronised to other open tabs on the same origin.

Preview login at `/admin-login`:

- Username: `admin`
- Password: `MoraHome@2025`

The login screen explicitly identifies preview mode. The Settings page can change the local password. A changed local password is stored using salted PBKDF2, but browser-side gating is still **not production authentication**. The preview's session and data can be modified by someone with access to that browser. Never use this mode as a production admin system or as a shared lead database.

Preview forms POST to `https://formsubmit.co/ajax/writemora@gmail.com`. The mailbox owner must activate FormSubmit using its initial confirmation email before it can forward submissions. A request is only marked as accepted after a successful API response. Offline or rejected requests remain in the local workspace with a failed email status, and the visitor is given retry and direct-email options. The admin can also retry an email from a lead's detail dialog. The application does not claim an email was delivered when the provider has not accepted it.

Clearing browser data deletes preview edits and locally saved enquiries. Export products and leads in Settings before clearing storage. Large collections of uploaded photos can exceed browser storage quotas; production mode stores photographs on the server instead.

## Production Deployment

The included `netlify/functions/api.mjs` provides shared persistence, server-checked admin access and server-side email sending. No private API keys or admin passwords are placed in the frontend.

1. Deploy the repository to Netlify with continuous deployment. `netlify.toml` configures the Vite build, functions, SPA route fallback, security headers and `/api` rewrites.
2. Add `ADMIN_USERNAME` and a strong `ADMIN_PASSWORD` of at least 12 characters as server/function environment variables in Netlify. Do not use the preview credentials.
3. Add a randomly generated `ADMIN_SESSION_SECRET` of at least 32 characters. It is used for signed, eight-hour, HttpOnly, Secure, SameSite=Strict session cookies. Rotating it, the admin username or the password invalidates existing sessions.
4. Create a Resend API key and verify a sending domain that you own. Add `RESEND_API_KEY` and `EMAIL_FROM`, for example `MORA HOME <enquiries@your-verified-domain.in>`, as server/function environment variables. Resend's restricted test sender is not suitable for arbitrary production recipients.
5. Set `SITE_ORIGIN` to the actual production origin, such as `https://morahome.in`. The destination mailbox is fixed to `writemora@gmail.com` on the server.
6. Optionally set `MORA_STORE` to a store name. Netlify provisions the private Blobs store automatically. Use distinct store names and independently scoped credentials for production and deploy previews so a preview cannot modify live business data.
7. Deploy again. The build uses `VITE_API_BASE=/api` from `netlify.toml`. API misconfiguration produces an explicit error; it does not silently switch a live deployment to local mode.
8. Visit `/admin-login`, sign in using the server credentials, and add verified products. The production catalogue starts empty. Settings can optionally import the six illustrative sample products for a staging demonstration.
9. Run the verification checklist below before pointing the live domain to the deployment.

`.env.example` lists the variable names without supplying secrets. Never add a `VITE_` prefix to a server secret. Netlify function environment variables must be configured in the hosting dashboard or CLI with the appropriate runtime scope; a local `.env` alone does not configure hosted functions.

The server uses strongly consistent Blobs reads, conditional-write rate limits for login and lead endpoints, same-origin checks for mutations, strict field validation, MIME and file-signature checks for uploaded images, authenticated writes and private lead reads. Product responses shown publicly exclude drafts. Image files are delivered through a dedicated public image route, never an arbitrary storage-key endpoint. CSV exports defend against formula injection, and rich descriptions use an element/attribute allowlist before display.

If the email service is unavailable, a production request is still saved in the shared inbox, marked as failed, and can be retried from the workspace after the email service is configured. Provider acceptance is not a guarantee of mailbox delivery; check the provider's delivery log and the recipient inbox.

## Content & Photography

The six seed products in `src/data/catalogue.ts` have illustrative names, dimensions and specifications. Photography in `public/images` is AI-generated for the website demonstration. Gallery views include labelled detail crops of that photography, not eight independently photographed angles of each real product. Uploaded product images are displayed as supplied, up to eight per item.

Replace sample photographs, product specifications and manufacturing claims with business-approved content before launch. The ornamental vector mark in `src/components/Brand.tsx` is a recreation inspired by the supplied MORA reference, not the original image file. It can be replaced with the final approved vector logo.

Every product carries a searchable product code in the `HM-2001` format. It appears under the product name on `/products`, in the product specifications, in the admin list, and is included in catalogue search (buyers can type `HM-2001` to find a piece instantly). Codes are auto-suggested from the highest existing code in the admin form and validated server-side as `HM-` followed by 4 to 6 digits, unique per product. The "Request Now" catalogue form collects Full Name, Contact Number, City and Business Type; city is required and is included in the admin catalogue table and CSV export.

New uploads accept JPG, PNG and WebP. The browser resizes the longest dimension to 1,200 pixels, removes source metadata through a canvas re-encode, and generates an optimised JPEG. The server limits each optimised photograph to 1 MB and the request body to 4.5 MB. The first photograph is the card cover, the second is the hover photograph, and the remaining photographs are available in the product gallery.

Google Fonts serves Cormorant Garamond and DM Sans; readable system fallbacks are provided. For fully self-hosted typography, replace the font links in `index.html` with licensed local font assets.

## Verification Checklist

- Open the homepage at phone, tablet and desktop widths. Check the sticky navigation, mobile menu, catalogue strip and both enquiry entry points.
- Open `/products` directly and via the main CTA. Filter by category, material, use and order type; combine filters; sort; search; clear filters; and check the no-results state.
- Open a product, select all thumbnails, enter fullscreen, use arrow keys, Escape, swipe, pinch and the zoom buttons. Check that product enquiries are pre-filled.
- Submit a catalogue request and a full enquiry using approved test contact data. Confirm actual receipt at `writemora@gmail.com` and that both records appear in a different, authenticated browser's workspace.
- Disconnect the email service in staging and verify that saved leads are marked failed and retry correctly after restoring the service.
- Confirm that an unauthenticated request cannot list leads, read drafts, upload images or mutate products. Check invalid-password, expired-session and rate-limit handling.
- Add a draft with eight photos, drag and keyboard-reorder them, publish it, verify it in a separate browser, edit it, hide it, and finally delete it.
- Mark an enquiry read, open its full message and export each lead table to CSV. Test a name beginning with a spreadsheet formula character.
- Reload nested product URLs, check unknown URLs, and verify the canonical tags, page titles, `robots.txt` and sitemap.
- Confirm all three contact links and the exact WhatsApp destination on a real mobile device.

The Vite production bundle is build-verified in this workspace. Hosted Netlify functions, live email delivery, real-device gestures and cross-browser rendering still require deployment/runtime testing with the owner's credentials. No live business enquiry or email was submitted during implementation.

## Operations

Back up the Blobs store and exported enquiries according to your business retention policy. Set provider spending limits and monitor function logs and email delivery failures. Deleting a product removes its catalogue record; orphaned uploaded image blobs are retained and can be cleaned up through the hosting console after backups. Static sample assets remain under `public/images` until removed from the project.