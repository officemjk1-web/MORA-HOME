import type { CategoryId, Product, ProductImage } from '../types';

export const categories: { id: CategoryId; name: string; shortName: string; description: string; image: string; icon: string }[] = [
  { id: 'kitchenware', name: 'Kitchenware', shortName: 'Kitchenware', description: 'Everyday essentials. Extraordinary craftsmanship.', image: '/images/kitchenware.jpg', icon: 'cooking' },
  { id: 'home-decor', name: 'Home Decor', shortName: 'Home Decor', description: 'Timeless accents for thoughtfully curated spaces.', image: '/images/home-decor.jpg', icon: 'vase' },
  { id: 'serveware', name: 'Serveware & Utensils', shortName: 'Serveware', description: 'Made to serve beautifully, for generations.', image: '/images/serveware.jpg', icon: 'utensils' },
  { id: 'pooja-products', name: 'Pooja Products', shortName: 'Pooja Products', description: 'A little tradition. A little light. A sacred touch.', image: '/images/pooja.jpg', icon: 'flame' },
  { id: 'diwali-gifting', name: 'Diwali Gifting', shortName: 'Diwali Gifting', description: 'Thoughtful pieces for the season of togetherness.', image: '/images/diwali.jpg', icon: 'sparkles' },
  { id: 'occasion-gifting', name: 'Occasion & Return Gifting', shortName: 'Occasion Gifting', description: 'Memorable gestures, made with meaning.', image: '/images/gifting.jpg', icon: 'gift' },
];

export const businessTypes = ['Wholesaler', 'Retailer', 'Stockist', 'Corporate Gifting', 'Return Gifting', 'Occasion Gifting', 'Bulk Buyer'];
export const materialOptions = ['Brass', 'Iron', 'Mixed Metal', 'Stainless Steel', 'Copper Finish', 'Antique Finish'];
export const useOptions = ['Daily Use', 'Festive Decor', 'Corporate Gifting', 'Return Gifting', 'Wedding Gifting', 'Pooja & Ritual', 'Table Display'];
export const orderOptions = ['Bulk Orders', 'Wholesale', 'Retail Stock', 'Custom / Private Label'];

export const categoryName = (id: string) => categories.find((category) => category.id === id)?.name || id;
export const slugify = (text: string) => text.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

// The sample gallery includes overall photography and deliberately labelled detail crops.
function gallery(src: string, name: string, alternate?: string): ProductImage[] {
  return [
    { src, alt: `${name}: full view` },
    { src: alternate || src, alt: `${name}: ${alternate ? 'alternate view' : 'surface detail'}`, zoom: alternate ? 1 : 1.5, x: 50, y: 40 },
    { src, alt: `${name}: hand-finished texture`, zoom: 2.1, x: 40, y: 40 },
    { src, alt: `${name}: upper detail`, zoom: 1.8, x: 50, y: 20 },
    { src, alt: `${name}: base detail`, zoom: 1.7, x: 50, y: 75 },
    { src: alternate || src, alt: `${name}: artisan detailing`, zoom: 1.6, x: 65, y: 45 },
    { src, alt: `${name}: finish close-up`, zoom: 2.3, x: 60, y: 55 },
    { src: alternate || src, alt: `${name}: collection view` },
  ];
}

export const seedProducts: Product[] = [
  {
    id: 'mora-001', slug: 'hammered-brass-water-set', productCode: 'HM-2001', name: 'Hammered Brass Water Set', category: 'kitchenware',
    tagline: 'An everyday ritual, beautifully reimagined.',
    description: '<p>A considered addition to the everyday table, this handcrafted brass pitcher and tumbler set celebrates the metalworking heritage of Moradabad. Its softly hammered surface catches the light with quiet warmth.</p><p>Each piece is individually finished by our artisans. Custom packaging and private-label options are available for wholesale and gifting orders.</p>',
    material: 'Brass', dimensions: 'Pitcher: 22 x 15 cm; tumblers: 9 x 7 cm', idealFor: ['Daily Use', 'Corporate Gifting', 'Table Display'], gifting: 'Corporate, housewarming & festive gifting', finish: 'Hand-hammered Gold', orderTypes: [...orderOptions],
    images: gallery('/images/kitchenware.jpg', 'Hammered Brass Water Set', '/images/kitchenware-detail.jpg'), status: 'Published', createdAt: '2025-10-06T10:00:00.000Z',
  },
  {
    id: 'mora-002', slug: 'gulmohar-engraved-brass-vase', productCode: 'HM-2002', name: 'Gulmohar Engraved Brass Vase', category: 'home-decor',
    tagline: 'A quiet statement. A lasting impression.',
    description: '<p>Botanical engravings trace the curved silhouette of this handcrafted brass vase, bringing a little of India\'s ornamental heritage into contemporary spaces.</p><p>Made and finished in Moradabad, its antique patina makes every piece subtly individual. An elegant choice for retail collections, hospitality styling and thoughtful gifting.</p>',
    material: 'Brass', dimensions: '28 cm height x 18 cm diameter', idealFor: ['Table Display', 'Corporate Gifting', 'Wedding Gifting'], gifting: 'Housewarming & premium corporate gifts', finish: 'Antique Gold', orderTypes: [...orderOptions],
    images: gallery('/images/home-decor.jpg', 'Gulmohar Engraved Brass Vase'), status: 'Published', createdAt: '2025-10-05T10:00:00.000Z',
  },
  {
    id: 'mora-003', slug: 'heritage-brass-serving-set', productCode: 'HM-2003', name: 'Heritage Brass Serving Set', category: 'serveware',
    tagline: 'Bring a sense of occasion to every table.',
    description: '<p>A beautifully detailed serving platter, three bowls and a matching spoon come together in this heritage-inspired set. Handcrafted floral details honour traditional Indian metalwork.</p><p>Designed for considered entertaining and exceptional gifting, the set can be supplied with customised presentation packaging for bulk orders.</p>',
    material: 'Brass', dimensions: 'Tray: 30 cm diameter; bowls: 9 cm diameter', idealFor: ['Daily Use', 'Table Display', 'Wedding Gifting'], gifting: 'Wedding, festive & corporate gifting', finish: 'Engraved Antique Gold', orderTypes: [...orderOptions],
    images: gallery('/images/serveware.jpg', 'Heritage Brass Serving Set'), status: 'Published', createdAt: '2025-10-04T10:00:00.000Z',
  },
  {
    id: 'mora-004', slug: 'mayur-lotus-brass-diya', productCode: 'HM-2004', name: 'Mayur Lotus Brass Diya', category: 'pooja-products',
    tagline: 'Light a tradition. Share a little warmth.',
    description: '<p>A graceful peacock rises above a lotus-shaped bowl in this traditional brass diya. Carefully sculpted petals and hand-finished details make it a timeless companion to daily rituals.</p><p>Crafted by skilled hands in Moradabad, it is equally at home in a personal pooja space or a thoughtfully curated festive gift box. Bulk and custom-packaged orders are welcome.</p>',
    material: 'Brass', dimensions: '15 cm height x 12 cm width', idealFor: ['Pooja & Ritual', 'Festive Decor', 'Return Gifting'], gifting: 'Diwali, weddings & return gifting', finish: 'Antique Gold', orderTypes: [...orderOptions],
    images: gallery('/images/pooja.jpg', 'Mayur Lotus Brass Diya', '/images/pooja-detail.jpg'), status: 'Published', createdAt: '2025-10-03T10:00:00.000Z',
  },
  {
    id: 'mora-005', slug: 'jali-tealight-holder-trio', productCode: 'HM-2005', name: 'Jali Tealight Holder Trio', category: 'diwali-gifting',
    tagline: 'Little lights. Beautiful celebrations.',
    description: '<p>Inspired by the latticework of Indian architecture, these three pierced-metal tealight holders scatter a delicate pattern of light. Graduated heights make an effortless festive centrepiece.</p><p>Hand-finished in a warm antique-gold tone, this trio is ready for seasonal retail collections and custom festive hampers.</p>',
    material: 'Iron', dimensions: 'Heights: 10, 13 & 16 cm', idealFor: ['Festive Decor', 'Corporate Gifting', 'Table Display'], gifting: 'Diwali hampers & festive gifting', finish: 'Antique Gold', orderTypes: [...orderOptions],
    images: gallery('/images/diwali.jpg', 'Jali Tealight Holder Trio'), status: 'Published', createdAt: '2025-10-02T10:00:00.000Z',
  },
  {
    id: 'mora-006', slug: 'utsav-celebration-gift-box', productCode: 'HM-2006', name: 'Utsav Celebration Gift Box', category: 'occasion-gifting',
    tagline: 'A thoughtful thank you, beautifully made.',
    description: '<p>Two lotus tealight holders and an engraved bowl are nestled in a beautifully lined presentation box. A keepsake collection that brings together the warmth of Indian craft and the joy of giving.</p><p>Choose custom colours, branded sleeves and personalised inserts for wedding return gifts, corporate occasions and milestone celebrations.</p>',
    material: 'Mixed Metal', dimensions: 'Gift box: 25 x 25 x 10 cm', idealFor: ['Return Gifting', 'Wedding Gifting', 'Corporate Gifting'], gifting: 'Wedding, occasion & corporate gifting', finish: 'Warm Antique Gold', orderTypes: [...orderOptions],
    images: gallery('/images/gifting.jpg', 'Utsav Celebration Gift Box'), status: 'Published', createdAt: '2025-10-01T10:00:00.000Z',
  },
];