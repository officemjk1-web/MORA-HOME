import type { ProductImage } from '../types';

export function isValidPhone(value: string) {
  return /^\+?[0-9 ()-]{10,20}$/.test(value.trim()) && /^[0-9]{10,15}$/.test(value.replace(/\D/g, ''));
}

export function readLocal<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) as T : fallback;
  } catch {
    return fallback;
  }
}

export function writeLocal(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    throw new Error('Browser storage is full or unavailable. Export your data, or use the connected production backend.');
  }
}

export function exportCSV(filename: string, rows: Record<string, string>[]) {
  if (!rows.length) return;
  const headers = Object.keys(rows[0]);
  const escape = (value: string) => {
    const safe = /^\s*[=+\-@]/.test(value) || /^[\t\r\n]/.test(value) ? `'${value}` : value;
    return `"${safe.replace(/"/g, '""')}"`;
  };
  const text = [headers.map(escape).join(','), ...rows.map((row) => headers.map((key) => escape(row[key] || '')).join(','))].join('\r\n');
  downloadFile(filename, new Blob(['\uFEFF', text], { type: 'text/csv;charset=utf-8;' }));
}

export function downloadFile(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function sanitizeRichText(html: string): string {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const allowed = new Set(['P', 'BR', 'STRONG', 'B', 'EM', 'I', 'U', 'UL', 'OL', 'LI', 'H3']);
  doc.querySelectorAll('script, style, iframe, object, embed, svg, math, template').forEach((el) => el.remove());
  Array.from(doc.body.querySelectorAll('*')).reverse().forEach((el) => {
    if (!allowed.has(el.tagName)) el.replaceWith(...Array.from(el.childNodes));
    else Array.from(el.attributes).forEach((attr) => el.removeAttribute(attr.name));
  });
  return doc.body.innerHTML;
}

export function plainText(html: string) {
  return new DOMParser().parseFromString(html, 'text/html').body.textContent || '';
}

export function dateLabel(date: string) {
  return new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export async function compressImage(file: File): Promise<ProductImage> {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('Please upload JPG, PNG or WebP images.');
  if (file.size > 12 * 1024 * 1024) throw new Error('Please choose images smaller than 12 MB.');
  const url = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('This image could not be read. Please try another file.'));
      img.src = url;
    });
    const ratio = Math.min(1, 1200 / Math.max(image.width, image.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(image.width * ratio);
    canvas.height = Math.round(image.height * ratio);
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Image processing is not available in this browser.');
    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    return { src: canvas.toDataURL('image/jpeg', 0.8), alt: file.name.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' ') };
  } finally {
    URL.revokeObjectURL(url);
  }
}