import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { seedProducts } from '../data/catalogue';
import type { Lead, LeadInput, Product, SubmissionResult } from '../types';
import { plainText, readLocal, writeLocal } from './utils';

const API = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, '') || '';
export const isLiveMode = Boolean(API);
const PRODUCT_KEY = 'mora-products-v1';
const LEAD_KEY = 'mora-leads-v1';
const AUTH_KEY = 'mora-local-auth-v1';
const SESSION_KEY = 'mora-local-session-v1';

function hasLocalSession() {
  try { return Number(sessionStorage.getItem(SESSION_KEY) || 0) > Date.now(); }
  catch { return false; }
}

async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API}${path}`, {
    ...options, credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...options.headers },
    signal: options.signal || AbortSignal.timeout(20000),
  });
  if (!response.headers.get('content-type')?.includes('application/json')) throw new Error('The production API is unavailable. Please check the deployment configuration.');
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'The request could not be completed. Please try again.');
  return data as T;
}

async function passwordHash(password: string, salt: string) {
  const encoder = new TextEncoder();
  const material = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: encoder.encode(salt), iterations: 120000, hash: 'SHA-256' }, material, 256);
  return Array.from(new Uint8Array(bits)).map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

interface StoreContextValue {
  products: Product[];
  leads: Lead[];
  isAdmin: boolean;
  loading: boolean;
  error: string;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  saveProduct: (product: Product) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  submitLead: (lead: LeadInput) => Promise<SubmissionResult>;
  markRead: (id: string) => Promise<void>;
  retryEmail: (id: string) => Promise<void>;
  changePassword: (current: string, next: string) => Promise<void>;
  refresh: () => Promise<void>;
  importSamples: () => Promise<void>;
}

const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(() => isLiveMode ? [] : readLocal(PRODUCT_KEY, seedProducts));
  const [leads, setLeads] = useState<Lead[]>(() => isLiveMode ? [] : readLocal(LEAD_KEY, []));
  const [isAdmin, setIsAdmin] = useState(() => !isLiveMode && hasLocalSession());
  const [loading, setLoading] = useState(isLiveMode);
  const [error, setError] = useState('');

  const fetchData = useCallback(async (admin: boolean) => {
    if (!isLiveMode) {
      setProducts(readLocal(PRODUCT_KEY, seedProducts));
      setLeads(readLocal(LEAD_KEY, []));
      return;
    }
    const data = await api<{ products: Product[] }>(`/products${admin ? '?scope=all' : ''}`);
    setProducts(data.products);
    if (admin) {
      const inbox = await api<{ leads: Lead[] }>('/leads');
      setLeads(inbox.leads);
    }
    setError('');
  }, []);

  useEffect(() => {
    if (!isLiveMode) return;
    let cancelled = false;
    (async () => {
      try {
        const session = await api<{ authenticated: boolean }>('/session');
        if (cancelled) return;
        setIsAdmin(session.authenticated);
        await fetchData(session.authenticated);
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Unable to connect. Please try again.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [fetchData]);

  useEffect(() => {
    const onStorage = (event: StorageEvent) => {
      if (isLiveMode) return;
      if (event.key === PRODUCT_KEY) setProducts(readLocal(PRODUCT_KEY, seedProducts));
      if (event.key === LEAD_KEY) setLeads(readLocal(LEAD_KEY, []));
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  useEffect(() => {
    if (!isLiveMode) return;
    let lastRefresh = 0;
    const onFocus = () => {
      if (document.visibilityState !== 'visible' || Date.now() - lastRefresh < 5000) return;
      lastRefresh = Date.now();
      void fetchData(isAdmin).catch(() => undefined);
    };
    window.addEventListener('focus', onFocus);
    document.addEventListener('visibilitychange', onFocus);
    return () => { window.removeEventListener('focus', onFocus); document.removeEventListener('visibilitychange', onFocus); };
  }, [fetchData, isAdmin]);

  const persistProducts = (next: Product[]) => {
    if (!isLiveMode) writeLocal(PRODUCT_KEY, next);
    setProducts(next);
  };

  async function login(username: string, password: string) {
    if (isLiveMode) {
      await api('/login', { method: 'POST', body: JSON.stringify({ username, password }) });
      await fetchData(true);
    } else {
      const stored = readLocal<{ username: string; hash: string; salt: string } | null>(AUTH_KEY, null);
      const valid = stored ? username === stored.username && await passwordHash(password, stored.salt) === stored.hash : username === 'admin' && password === 'MoraHome@2025';
      if (!valid) throw new Error('The username or password is incorrect.');
      sessionStorage.setItem(SESSION_KEY, String(Date.now() + 8 * 60 * 60 * 1000));
    }
    setIsAdmin(true);
  }

  async function logout() {
    if (isLiveMode) await api('/logout', { method: 'POST' });
    else sessionStorage.removeItem(SESSION_KEY);
    setIsAdmin(false);
    if (isLiveMode) { setLeads([]); await fetchData(false); }
  }

  async function saveProduct(product: Product) {
    if (!isAdmin) throw new Error('Please sign in to manage products.');
    if (!product.name.trim()) throw new Error('A product name is required.');
    if (product.status === 'Published' && (!product.images.length || !plainText(product.description).trim())) throw new Error('Add at least one photograph and a description before publishing this product.');
    let saved = product;
    if (isLiveMode) {
      const result = await api<{ product: Product }>(`/products/${encodeURIComponent(product.id)}`, { method: 'PUT', body: JSON.stringify(product) });
      saved = result.product;
    }
    const current = isLiveMode ? products : readLocal<Product[]>(PRODUCT_KEY, products);
    persistProducts(current.some((item) => item.id === saved.id) ? current.map((item) => item.id === saved.id ? saved : item) : [saved, ...current]);
  }

  async function deleteProduct(id: string) {
    if (!isAdmin) throw new Error('Please sign in to manage products.');
    if (isLiveMode) await api(`/products/${encodeURIComponent(id)}`, { method: 'DELETE' });
    persistProducts(products.filter((product) => product.id !== id));
  }

  function persistLead(lead: Lead) {
    const current = readLocal<Lead[]>(LEAD_KEY, []);
    const next = [lead, ...current.filter((item) => item.id !== lead.id)];
    writeLocal(LEAD_KEY, next);
    setLeads(next);
  }

  async function submitLead(input: LeadInput): Promise<SubmissionResult> {
    if (isLiveMode) {
      const result = await api<SubmissionResult>('/leads', { method: 'POST', body: JSON.stringify(input) });
      if (isAdmin) await fetchData(true);
      return { ...result, local: false };
    }
    const existing = readLocal<Lead[]>(LEAD_KEY, []).find((lead) => lead.id === input.id);
    if (existing?.emailStatus === 'Sent') return { delivered: true, stored: true, local: true };
    const lead: Lead = { businessName: '', city: '', category: '', businessType: '', product: '', message: '', ...input, createdAt: existing?.createdAt || new Date().toISOString(), status: existing?.status || 'New', emailStatus: 'Pending' };
    persistLead(lead);
    try {
      const response = await fetch('https://formsubmit.co/ajax/writemora@gmail.com', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, signal: AbortSignal.timeout(15000),
        body: JSON.stringify({
          _subject: `MORA HOME | ${input.kind === 'catalogue' ? 'Catalogue request' : 'Business enquiry'} | ${input.name}`,
          _template: 'table', _captcha: 'false',
          Name: input.name, Phone: input.phone, Business: input.businessName || input.businessType || '', City: input.city || '',
          Category: input.category || '', Product: input.product || '', Message: input.message || 'Please share your wholesale catalogue and pricing.',
        }),
      });
      const result = await response.json();
      if (!response.ok || !(result.success === true || result.success === 'true') || /activat/i.test(String(result.message || ''))) throw new Error('Email service unavailable or awaiting activation.');
      persistLead({ ...lead, emailStatus: 'Sent' });
      return { delivered: true, stored: true, local: true };
    } catch {
      persistLead({ ...lead, emailStatus: 'Failed' });
      return { delivered: false, stored: true, local: true };
    }
  }

  async function markRead(id: string) {
    if (!isAdmin) throw new Error('Please sign in to manage enquiries.');
    if (isLiveMode) await api(`/leads/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ status: 'Read' }) });
    const next = leads.map((lead): Lead => lead.id === id ? { ...lead, status: 'Read' } : lead);
    if (!isLiveMode) writeLocal(LEAD_KEY, next);
    setLeads(next);
  }

  async function retryEmail(id: string) {
    if (!isAdmin) throw new Error('Please sign in to manage enquiries.');
    const lead = leads.find((item) => item.id === id);
    if (!lead) throw new Error('This enquiry could not be found.');
    let delivered = false;
    if (isLiveMode) {
      const result = await api<{ delivered: boolean }>(`/retry-email/${encodeURIComponent(id)}`, { method: 'POST' });
      delivered = result.delivered;
      setLeads((current) => current.map((item): Lead => item.id === id ? { ...item, emailStatus: delivered ? 'Sent' : 'Failed' } : item));
    } else {
      delivered = (await submitLead(lead)).delivered;
    }
    if (!delivered) throw new Error('Email could not be sent. Check the email service configuration, or contact this customer directly. Their enquiry remains saved.');
  }

  async function changePassword(current: string, next: string) {
    if (!isAdmin) throw new Error('Please sign in first.');
    if (isLiveMode) throw new Error('Production credentials are managed securely in your hosting environment.');
    const stored = readLocal<{ username: string; hash: string; salt: string } | null>(AUTH_KEY, null);
    const valid = stored ? await passwordHash(current, stored.salt) === stored.hash : current === 'MoraHome@2025';
    if (!valid) throw new Error('Your current password is incorrect.');
    if (next.length < 10) throw new Error('Choose a password with at least 10 characters.');
    const salt = crypto.randomUUID();
    writeLocal(AUTH_KEY, { username: stored?.username || 'admin', salt, hash: await passwordHash(next, salt) });
  }

  async function importSamples() {
    if (!isAdmin) throw new Error('Please sign in first.');
    if (isLiveMode) {
      for (const product of seedProducts) {
        await api(`/products/${product.id}`, { method: 'PUT', body: JSON.stringify(product) });
      }
      await fetchData(true);
    } else persistProducts([...seedProducts, ...products.filter((product) => !seedProducts.some((sample) => sample.id === product.id))]);
  }

  const refresh = async () => {
    setLoading(true);
    try { await fetchData(isAdmin); } catch (err) { setError(err instanceof Error ? err.message : 'Unable to load data.'); } finally { setLoading(false); }
  };

  return <StoreContext.Provider value={{ products, leads, isAdmin, loading, error, login, logout, saveProduct, deleteProduct, submitLead, markRead, retryEmail, changePassword, refresh, importSamples }}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used inside StoreProvider.');
  return context;
}