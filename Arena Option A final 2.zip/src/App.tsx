import { useEffect } from 'react';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import { StoreProvider, useStore } from './lib/store';
import { EnquiryProvider } from './components/Enquiries';
import { Layout, NotFound } from './components/Layout';
import { Home } from './pages/Home';
import { Products } from './pages/Products';
import { ProductDetail } from './pages/ProductDetail';
import { Admin } from './pages/Admin';

function PageMetadata() {
  const { pathname } = useLocation();
  const { products } = useStore();
  useEffect(() => {
    const product = products.find((item) => `/products/${item.slug}` === pathname);
    document.title = pathname === '/admin-login' ? 'MORA HOME | Private Workspace' : product ? `${product.name} | Handcrafted in Moradabad | MORA HOME` : pathname === '/products' ? 'Our Handcrafted Collection | MORA HOME' : 'MORA HOME | Wholesale Handcrafted Kitchenware & Home Decor | Moradabad Manufacturer';
    let robots = document.querySelector<HTMLMetaElement>('meta[name="robots"]');
    if (!robots) { robots = document.createElement('meta'); robots.name = 'robots'; document.head.append(robots); }
    robots.content = pathname.startsWith('/admin') ? 'noindex, nofollow' : 'index, follow';
    const canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (canonical) canonical.href = `https://morahome.in${pathname === '/' ? '/' : pathname}`;
    const description = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (description) description.content = product ? `${product.name}. ${product.tagline} Handcrafted in Moradabad, India. Contact MORA HOME for wholesale, bulk orders and custom gifting.` : 'Moradabad-based manufacturer of handcrafted brass, iron & metal kitchenware, home decor, serveware, pooja & gifting products. B2B wholesale & bulk orders.';
  }, [pathname, products]);
  return null;
}

export default function App() {
  return <BrowserRouter><StoreProvider><EnquiryProvider><PageMetadata /><Routes><Route element={<Layout />}><Route index element={<Home />} /><Route path="products" element={<Products />} /><Route path="products/:slug" element={<ProductDetail />} /><Route path="admin-login" element={<Admin />} /><Route path="*" element={<NotFound />} /></Route></Routes></EnquiryProvider></StoreProvider></BrowserRouter>;
}
