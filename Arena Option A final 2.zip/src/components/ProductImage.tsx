import type { CSSProperties } from 'react';
import type { ProductImage as ProductImageType } from '../types';

export function ProductImage({ image, className = '', eager = false }: { image: ProductImageType | undefined; className?: string; eager?: boolean }) {
  if (!image) return <div className={`image-placeholder ${className}`} aria-label="Product photography coming soon"><span>MORA<span>HOME</span></span></div>;
  return <div className={`product-photo ${className}`} style={{ '--view-zoom': image.zoom || 1, '--view-x': `${image.x ?? 50}%`, '--view-y': `${image.y ?? 50}%` } as CSSProperties}><img src={image.src} alt={image.alt} loading={eager ? 'eager' : 'lazy'} draggable={false} /></div>;
}