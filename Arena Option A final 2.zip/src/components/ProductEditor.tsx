import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowDown, ArrowUp, Bold, Check, GripVertical, ImagePlus, Italic, List, LoaderCircle, Plus, Upload, X } from 'lucide-react';
import { categories, materialOptions, orderOptions, slugify } from '../data/catalogue';
import { compressImage, plainText, sanitizeRichText } from '../lib/utils';
import { useStore } from '../lib/store';
import type { Product, ProductImage as ImageType } from '../types';
import { Modal } from './Modal';
import { ProductImage } from './ProductImage';

function RichEditor({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { if (ref.current) ref.current.innerHTML = sanitizeRichText(value); }, []);
  function format(command: string) {
    ref.current?.focus();
    document.execCommand(command);
    onChange(ref.current?.innerHTML || '');
  }
  return <div className="rich-editor"><div className="editor-toolbar">{[{ command: 'bold', label: 'Bold', icon: Bold }, { command: 'italic', label: 'Italic', icon: Italic }, { command: 'insertUnorderedList', label: 'Bullet list', icon: List }].map(({ command, label, icon: Icon }) => <button type="button" className="icon-button" key={command} onMouseDown={(event) => event.preventDefault()} onClick={() => format(command)} aria-label={label} title={label}><Icon size={16} /></button>)}</div><div ref={ref} className="rich-editor-content rich-text" contentEditable suppressContentEditableWarning role="textbox" aria-label="Full product description" aria-multiline="true" onInput={(event) => onChange(event.currentTarget.innerHTML)} onPaste={(event) => { event.preventDefault(); document.execCommand('insertText', false, event.clipboardData.getData('text/plain')); onChange(ref.current?.innerHTML || ''); }} data-placeholder="Tell the story of this piece..." /></div>;
}

export function nextProductCode(products: Product[]) {
  const highest = products.reduce((max, item) => {
    const match = /^HM-(\d{4,6})$/.exec(item.productCode || '');
    return match ? Math.max(max, Number(match[1])) : max;
  }, 2000);
  return `HM-${Math.max(2001, highest + 1)}`;
}

function blankProduct(productCode: string): Product {
  return { id: crypto.randomUUID(), slug: '', productCode, name: '', category: 'kitchenware', tagline: '', description: '', material: '', dimensions: '', idealFor: [], gifting: '', finish: '', orderTypes: ['Bulk Orders', 'Wholesale'], images: [], status: 'Published', createdAt: new Date().toISOString() };
}

export function ProductEditor({ product, onClose, onSaved }: { product?: Product; onClose: () => void; onSaved: (message: string) => void }) {
  const { saveProduct, products } = useStore();
  const [draft, setDraft] = useState<Product>(() => product ? structuredClone(product) : blankProduct(nextProductCode(products)));
  const [idealFor, setIdealFor] = useState(product?.idealFor.join(', ') || '');
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const dragIndex = useRef<number | null>(null);
  const update = <K extends keyof Product>(key: K, value: Product[K]) => setDraft((current) => ({ ...current, [key]: value }));

  async function upload(files: FileList | File[]) {
    if (uploading) return;
    const remaining = 8 - draft.images.length;
    if (files.length > remaining) { setError(`You can add ${remaining} more ${remaining === 1 ? 'image' : 'images'}. Each product supports up to 8.`); return; }
    setUploading(true); setError('');
    try {
      const images = await Promise.all(Array.from(files).map(compressImage));
      setDraft((current) => ({ ...current, images: [...current.images, ...images].slice(0, 8) }));
    } catch (err) { setError(err instanceof Error ? err.message : 'Unable to upload these images.'); }
    finally { setUploading(false); if (fileInput.current) fileInput.current.value = ''; }
  }

  function reorder(from: number, to: number) {
    if (to < 0 || to >= draft.images.length || from === to) return;
    setDraft((current) => {
      const images = [...current.images];
      images.splice(to, 0, images.splice(from, 1)[0]);
      return { ...current, images };
    });
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || uploading) return;
    if (!draft.name.trim()) { setError('Please enter a product name.'); return; }
    if (!/^HM-\d{4,6}$/i.test(draft.productCode.trim())) { setError('Please use a product code like HM-2001 (letters HM, a hyphen, then 4 to 6 digits).'); return; }
    if (draft.status === 'Published' && !draft.images.length) { setError('Add at least one product photo before publishing. You can also save this as a draft.'); return; }
    if (draft.status === 'Published' && !plainText(draft.description).trim()) { setError('Add a description before publishing.'); return; }
    if (draft.description.length > 15000) { setError('Please keep the product description under 15,000 characters.'); return; }
    setBusy(true); setError('');
    let slug = product?.slug || slugify(draft.name) || `product-${draft.id.slice(0, 8)}`;
    if (products.some((item) => item.slug === slug && item.id !== draft.id)) slug = `${slug}-${draft.id.slice(0, 6)}`;
    const images: ImageType[] = draft.images.map((image, index) => ({ ...image, alt: `${draft.name.trim()} - image ${index + 1}` }));
    try {
      await saveProduct({ ...draft, name: draft.name.trim(), productCode: draft.productCode.trim().toUpperCase(), slug, description: sanitizeRichText(draft.description), idealFor: idealFor.split(',').map((value) => value.trim()).filter(Boolean), images });
      onSaved(product ? 'Product updated successfully.' : draft.status === 'Published' ? 'Product published to your collection.' : 'Your draft has been saved.');
      onClose();
    } catch (err) { setError(err instanceof Error ? err.message : 'Your product could not be saved.'); }
    finally { setBusy(false); }
  }

  return <Modal label={product ? 'Edit product' : 'Add new product'} onClose={() => { if (!busy && !uploading) onClose(); }} className="product-editor-modal">
    <span className="eyebrow">THE MORA COLLECTION</span><h2>{product ? 'Refine a beautiful piece.' : 'Make room for something beautiful.'}</h2><p className="editor-subtitle">Add the details. Let the craftsmanship speak for itself.</p>
    <form onSubmit={submit} className="lead-form product-editor-form"><div className="form-grid">
      <label className="full-width">Product Name <span>*</span><input required maxLength={150} value={draft.name} onChange={(event) => update('name', event.target.value)} placeholder="e.g. Handcrafted Brass Diya Plate" /></label>
      <label>Category <span>*</span><select required value={draft.category} onChange={(event) => update('category', event.target.value as Product['category'])}>{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select></label>
      <label>Product Code <span>*</span><input required maxLength={20} value={draft.productCode} onChange={(event) => update('productCode', event.target.value.toUpperCase())} placeholder="HM-2001" /><small>Buyers can search the collection with this code.</small></label>
      <label>Material<input list="material-suggestions" value={draft.material} maxLength={100} onChange={(event) => update('material', event.target.value)} placeholder="e.g. Brass" /><datalist id="material-suggestions">{materialOptions.map((material) => <option value={material} key={material} />)}</datalist></label>
      <label className="full-width">Short Tagline<input maxLength={180} value={draft.tagline} onChange={(event) => update('tagline', event.target.value)} placeholder="One evocative line about this piece" /></label>
      <div className="field full-width"><span className="field-label">Full Description</span><RichEditor value={draft.description} onChange={(value) => update('description', value)} /></div>
      <label>Dimensions<input maxLength={180} value={draft.dimensions} onChange={(event) => update('dimensions', event.target.value)} placeholder="e.g. 20 x 20 x 8 cm" /></label>
      <label>Finish<input maxLength={120} value={draft.finish} onChange={(event) => update('finish', event.target.value)} placeholder="e.g. Antique Gold" /></label>
      <label>Ideal For<input maxLength={400} value={idealFor} onChange={(event) => setIdealFor(event.target.value)} placeholder="Corporate Gifting, Daily Use" /><small>Separate multiple uses with a comma.</small></label>
      <label>Gifting Suitability<input maxLength={180} value={draft.gifting} onChange={(event) => update('gifting', event.target.value)} placeholder="e.g. Corporate & festive gifting" /></label>
      <fieldset className="order-type-field full-width"><legend>Order Types</legend><div>{orderOptions.map((order) => <label className="checkbox-label" key={order}><input type="checkbox" checked={draft.orderTypes.includes(order)} onChange={() => update('orderTypes', draft.orderTypes.includes(order) ? draft.orderTypes.filter((value) => value !== order) : [...draft.orderTypes, order])} />{order}</label>)}</div></fieldset>
    </div>
    <div className="photo-upload-section"><div className="upload-section-heading"><h3>Product Photography</h3><span>{draft.images.length} / 8 images</span></div><p>First image: collection cover. Second image: hover view. Drag to reorder, or use the arrows.</p>
      <div className={`upload-zone ${dragging ? 'dragging' : ''}`} onDragOver={(event) => { event.preventDefault(); if (event.dataTransfer.types.includes('Files')) setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); if (event.dataTransfer.files.length) void upload(event.dataTransfer.files); }}>
        <input ref={fileInput} type="file" multiple accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={(event) => { if (event.target.files) void upload(event.target.files); }} />
        <button type="button" onClick={() => fileInput.current?.click()} disabled={uploading || draft.images.length >= 8}>{uploading ? <LoaderCircle className="spin" size={27} /> : <Upload size={27} strokeWidth={1.3} />}<strong>{uploading ? 'Preparing your photographs...' : 'Drop your photographs here, or browse'}</strong><span>JPG, PNG or WebP, up to 12 MB each. Automatically optimised.</span></button>
      </div>
      {draft.images.length > 0 && <div className="upload-thumbnails">{draft.images.map((image, index) => <div className="upload-thumbnail" key={`${index}-${image.src.slice(-30)}`} draggable onDragStart={(event) => { dragIndex.current = index; event.dataTransfer.effectAllowed = 'move'; event.dataTransfer.setData('text/plain', String(index)); }} onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); event.stopPropagation(); if (dragIndex.current !== null) reorder(dragIndex.current, index); dragIndex.current = null; }} onDragEnd={() => { dragIndex.current = null; }}><ProductImage image={image} /><span className="upload-position"><GripVertical size={11} />{index === 0 ? 'Cover' : index === 1 ? 'Hover' : index + 1}</span><button className="remove-upload" type="button" aria-label={`Remove image ${index + 1}`} onClick={() => update('images', draft.images.filter((_, photoIndex) => photoIndex !== index))}><X size={13} /></button><div className="image-reorder"><button type="button" onClick={() => reorder(index, index - 1)} disabled={index === 0} aria-label={`Move image ${index + 1} earlier`}><ArrowUp size={13} /></button><button type="button" onClick={() => reorder(index, index + 1)} disabled={index === draft.images.length - 1} aria-label={`Move image ${index + 1} later`}><ArrowDown size={13} /></button></div></div>)}</div>}
      {!draft.images.length && <div className="upload-empty-note"><ImagePlus size={15} />Show the finish, the form and the little details.</div>}
    </div>
    <div className="publish-setting"><label className="toggle-label"><input type="checkbox" checked={draft.status === 'Published'} onChange={(event) => update('status', event.target.checked ? 'Published' : 'Draft')} /><span className="toggle-track" /><span><strong>{draft.status === 'Published' ? 'Published' : 'Draft'}</strong><small>{draft.status === 'Published' ? 'Visible in the collection as soon as you save.' : 'Only visible to you in this workspace.'}</small></span></label></div>
    {error && <p className="form-error" role="alert">{error}</p>}
    <div className="editor-actions"><button type="button" className="button button-outline" onClick={onClose} disabled={busy || uploading}>Cancel</button><button type="submit" className="button button-gold" disabled={busy || uploading}>{busy ? <LoaderCircle className="spin" size={16} /> : product ? <Check size={17} /> : <Plus size={17} />}{busy ? 'Saving...' : product ? 'Save Changes' : 'Add Product'}</button></div>
    </form>
  </Modal>;
}
