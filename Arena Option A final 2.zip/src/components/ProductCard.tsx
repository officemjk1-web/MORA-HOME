import { Link } from 'react-router-dom';
import { ArrowRight, Diamond } from 'lucide-react';
import { categoryName } from '../data/catalogue';
import type { Product } from '../types';
import { useEnquiry } from './Enquiries';
import { ProductImage } from './ProductImage';

export function ProductCard({ product }: { product: Product }) {
  const { openEnquiry } = useEnquiry();
  return <article className="product-card">
    <Link className="product-card-link" to={`/products/${product.slug}`} aria-label={`View ${product.name}`}>
      <div className="product-card-images"><ProductImage image={product.images[0]} className="primary-photo" />{product.images[1] && <ProductImage image={product.images[1]} className="secondary-photo" />}</div>
      <div className="product-card-info"><span className="category-tag">{categoryName(product.category)}</span><h3>{product.name}</h3><p className="product-code">Product Code <strong>{product.productCode || 'On request'}</strong></p><div className="product-card-specs"><p><Diamond size={10} /><span>Material: <strong>{product.material || 'On request'}</strong></span></p><p><Diamond size={10} /><span>Ideal For: <strong>{product.idealFor[0] || 'On request'}</strong></span></p><p><Diamond size={10} /><span>Finish: <strong>{product.finish || 'On request'}</strong></span></p></div></div>
    </Link>
    <div className="product-card-action"><button className="button button-primary button-full" onClick={() => openEnquiry(product)}>Send Enquiry<ArrowRight size={15} /></button></div>
  </article>;
}