import { useId } from 'react';
import { CookingPot, Flower2, Flame, Gift, Sparkles, Utensils, type LucideProps } from 'lucide-react';

export function Brand({ variant = 'nav' }: { variant?: 'nav' | 'hero' | 'footer' | 'login' }) {
  const id = useId().replace(/:/g, '');
  return <span className={`brand brand--${variant}`}>
    <svg className="brand-emblem" viewBox="0 0 210 170" role="img" aria-label="MORA ornamental floral emblem">
      <defs>
        <path id={`${id}-arch`} d="M105 10 C116 32 151 24 154 47 C177 45 178 69 194 84 C178 98 177 124 154 122 C150 147 117 139 105 161 C92 139 60 147 56 122 C33 124 32 98 16 84 C32 69 33 45 56 47 C59 24 94 32 105 10Z" />
        <g id={`${id}-flower`}>
          <path d="M0 0C-13-4-11-15-8-16C-4-14 0-9 0 0ZM0 0C-5-12 1-20 4-19C7-15 6-7 0 0ZM0 0C7-12 17-13 18-10C15-5 9-1 0 0ZM0 0C11 0 15 7 14 10C8 10 2 6 0 0ZM0 0C-8 7-14 5-15 2C-11-2-6-2 0 0Z" />
          <circle r="3" fill="currentColor" stroke="none" />
        </g>
        <g id={`${id}-vine`}>
          <path d="M29 80C13 56 24 31 48 21M27 49C10 44 12 31 14 27C22 32 26 39 27 49ZM30 40C28 26 39 22 43 22C42 31 37 37 30 40ZM33 30C32 14 38 12 41 11C45 22 39 27 33 30M23 64C10 64 7 58 6 53C15 52 21 56 23 64M38 28C45 13 57 17 61 18C53 25 44 28 38 28" />
          <use href={`#${id}-flower`} transform="translate(32 61) rotate(-28) scale(.65)" />
          <path d="M48 18C56 16 60 8 53 6C49 5 48 10 51 11" />
        </g>
      </defs>
      <g fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round">
        <use href={`#${id}-arch`} />
        <use href={`#${id}-arch`} transform="translate(10.5 8.5) scale(.9)" strokeWidth="2.6" />
        <use href={`#${id}-arch`} transform="translate(20 16) scale(.81)" strokeWidth="1.3" />
        <use href={`#${id}-vine`} />
        <use href={`#${id}-vine`} transform="translate(210 0) scale(-1 1)" />
        <use href={`#${id}-vine`} transform="translate(0 170) scale(1 -1)" />
        <use href={`#${id}-vine`} transform="translate(210 170) scale(-1 -1)" />
        <path d="M105 27V47M105 47L109 53L105 60L101 53Z" />
        <use href={`#${id}-flower`} transform="translate(105 136) rotate(-48) scale(.65)" />
        <path d="M62 56C60 46 73 43 76 48C79 54 70 55 72 49M80 41C81 31 93 34 90 41M147 56C150 46 137 43 134 48C131 54 140 55 138 49M130 41C129 31 117 34 120 41M64 111C61 123 75 128 79 121M146 111C149 123 135 128 131 121" />
      </g>
      <text x="107" y="101" textAnchor="middle" fill="currentColor" fontFamily="Cormorant Garamond, Georgia, serif" fontSize="42" fontWeight="500" letterSpacing="4">MORA</text>
    </svg>
    {variant === 'hero' ? <span className="brand-home">H O M E</span> : <span className="brand-wordmark">MORA HOME<span>THE ART OF INDIAN LIVING</span></span>}
  </span>;
}

export function Ornament({ className = '' }: { className?: string }) {
  return <div className={`ornament ${className}`} aria-hidden="true"><span /><svg viewBox="0 0 70 24" fill="none" stroke="currentColor" strokeWidth="1.15">
    <path d="M2 12H24M46 12H68M35 4L43 12L35 20L27 12Z" />
    <path d="M25 12C17 11 14 5 17 4C22 3 25 8 25 12ZM25 12C18 12 14 18 17 20C22 21 25 16 25 12ZM45 12C53 11 56 5 53 4C48 3 45 8 45 12ZM45 12C52 12 56 18 53 20C48 21 45 16 45 12Z" />
    <circle cx="35" cy="12" r="2" fill="currentColor" />
  </svg><span /></div>;
}

export function CategoryIcon({ name, ...props }: LucideProps & { name: string }) {
  const icons = { cooking: CookingPot, vase: Flower2, flame: Flame, gift: Gift, sparkles: Sparkles, utensils: Utensils };
  const Component = icons[name as keyof typeof icons] || Gift;
  return <Component strokeWidth={1.4} aria-hidden="true" {...props} />;
}

export function WhatsAppIcon() {
  return <svg viewBox="0 0 32 32" fill="currentColor" aria-hidden="true"><path d="M16 3a12.6 12.6 0 0 0-10.9 19l-1.7 6.3 6.5-1.7A12.6 12.6 0 1 0 16 3Zm0 22.9c-2 0-3.8-.5-5.4-1.5l-.4-.2-3.9 1 1-3.8-.2-.4A10.4 10.4 0 1 1 16 25.9Zm5.7-7.8c-.3-.2-1.8-.9-2.1-1-.2-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.5-1.6-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.7l.5-.6.3-.5c.1-.2 0-.4 0-.6l-1-2.3c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.8.4-.3.3-1.1 1.1-1.1 2.6s1.1 3 1.3 3.2c.2.2 2.2 3.4 5.3 4.7.8.3 1.3.5 1.8.6.7.2 1.4.2 1.9.1.6-.1 1.8-.8 2-1.5.3-.7.3-1.3.2-1.4-.1-.1-.3-.2-.6-.3Z" /></svg>;
}