import { useEffect, useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { ArrowRight, BookOpen, ChevronDown, Mail, Menu, Phone } from 'lucide-react';
import { Brand, Ornament, WhatsAppIcon } from './Brand';
import { useEnquiry } from './Enquiries';
import { Modal } from './Modal';

const navLinks = [
  { label: 'Home', to: '/' }, { label: 'Products', to: '/products' }, { label: 'Categories', to: '/#categories' }, { label: 'About Us', to: '/#about' }, { label: 'Contact', to: '/#contact' },
];

function ScrollManager() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const timer = window.setTimeout(() => document.getElementById(hash.slice(1))?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
      return () => clearTimeout(timer);
    }
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [pathname, hash]);
  return null;
}

function Header() {
  const { openEnquiry, openCatalogue } = useEnquiry();
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  useEffect(() => setMenuOpen(false), [location.pathname, location.hash]);
  const isActive = (to: string) => to.includes('#') ? location.pathname === '/' && location.hash === `#${to.split('#')[1]}` : to === '/' ? location.pathname === '/' && !location.hash : location.pathname.startsWith(to);
  return <header className="site-header">
    <div className="navbar container">
      <Link to="/" className="logo-link" aria-label="MORA HOME home"><Brand /></Link>
      <nav className="desktop-nav" aria-label="Main navigation">{navLinks.map((link) => <Link key={link.label} to={link.to} aria-current={isActive(link.to) ? 'page' : undefined} className={isActive(link.to) ? 'nav-link active' : 'nav-link'}>{link.label}{link.label === 'Categories' && <ChevronDown size={11} />}</Link>)}</nav>
      <button className="button button-primary nav-enquiry" onClick={() => openEnquiry()}>Send Enquiry<ArrowRight size={15} /></button>
      <button className="icon-button mobile-menu-button" aria-label="Open navigation menu" aria-expanded={menuOpen} onClick={() => setMenuOpen(true)}><Menu size={26} strokeWidth={1.4} /></button>
    </div>
    <div className="catalogue-strip"><div className="container catalogue-strip-inner"><span><BookOpen size={15} strokeWidth={1.5} />Get Our Wholesale Catalogue &amp; Pricing <span className="catalogue-free">&nbsp; - Free</span></span><button onClick={openCatalogue}>Request Now<ArrowRight size={13} /></button></div></div>
    {menuOpen && <Modal label="Navigation menu" onClose={() => setMenuOpen(false)} className="navigation-drawer"><Link to="/" className="logo-link"><Brand /></Link><Ornament /><nav aria-label="Mobile navigation">{navLinks.map((link, index) => <Link key={link.label} to={link.to} onClick={() => setMenuOpen(false)}><span className="menu-number">0{index + 1}</span>{link.label}<ArrowRight size={20} /></Link>)}</nav><button className="button button-primary button-full" onClick={() => { setMenuOpen(false); openEnquiry(); }}>Send Enquiry<ArrowRight size={17} /></button><p className="drawer-tagline">Crafted in Moradabad.<br />Made for your business.</p></Modal>}
  </header>;
}

function Footer() {
  const { openCatalogue } = useEnquiry();
  return <footer className="footer">
    <div className="container">
      <div className="footer-brand"><Link to="/" aria-label="MORA HOME home"><Brand variant="footer" /></Link><p>Crafted in Moradabad. Delivered Across India.</p></div>
      <Ornament />
      <div className="footer-columns">
        <div><h3>A little heritage. A lasting partnership.</h3><p>Handcrafted brass, iron and metal homeware, straight from the artisans of Moradabad to your business.</p></div>
        <div><h4>EXPLORE MORA</h4><div className="footer-links">{navLinks.map((link) => <Link key={link.label} to={link.to}>{link.label}</Link>)}</div></div>
        <div><h4>LET'S CONNECT</h4><a href="mailto:writemora@gmail.com"><Mail size={14} />writemora@gmail.com</a><a href="mailto:asktomora@gmail.com"><Mail size={14} />asktomora@gmail.com</a><a href="tel:+918171246275"><Phone size={14} />+91 8171246275</a></div>
      </div>
      <div className="footer-catalogue"><div><BookOpen size={22} strokeWidth={1.25} /><span>Request Our Wholesale Catalogue &amp; Pricing</span></div><button onClick={openCatalogue}>Download Now<ArrowRight size={16} /></button></div>
      <div className="footer-bottom"><span>&copy; 2025 MORA HOME. All rights reserved.</span><span>This website is exclusively for B2B, wholesale &amp; gifting enquiries.</span><span>MADE IN INDIA</span></div>
    </div>
  </footer>;
}

function FloatingContact() {
  const { openEnquiry } = useEnquiry();
  return <div className="floating-contact"><button className="mobile-floating-enquiry" onClick={() => openEnquiry()}>Send Enquiry</button><a className="whatsapp-button" href="https://wa.me/918171246275" target="_blank" rel="noreferrer" aria-label="Chat with MORA HOME on WhatsApp"><WhatsAppIcon /></a></div>;
}

export function Layout() {
  return <><a className="skip-link" href="#main-content">Skip to content</a><ScrollManager /><Header /><main id="main-content"><Outlet /></main><Footer /><FloatingContact /></>;
}

export function NotFound() {
  return <section className="not-found container"><span className="eyebrow">A DIFFERENT PATH</span><h1>This page isn't in our collection.</h1><p>There is still plenty of beautiful craftsmanship to discover.</p><Link className="button button-primary" to="/products">Explore our collection<ArrowRight size={16} /></Link></section>;
}