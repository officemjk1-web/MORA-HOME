import { createContext, useContext, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowRight, Check, CircleCheck, LoaderCircle, Mail, ShieldCheck } from 'lucide-react';
import { businessTypes, categories } from '../data/catalogue';
import { useStore } from '../lib/store';
import { isValidPhone } from '../lib/utils';
import type { Product, SubmissionResult } from '../types';
import { Brand, Ornament } from './Brand';
import { Modal } from './Modal';

interface EnquiryContextValue {
  openEnquiry: (product?: Product, initialMessage?: string) => void;
  openCatalogue: () => void;
}
const EnquiryContext = createContext<EnquiryContextValue | null>(null);

export function EnquiryProvider({ children }: { children: ReactNode }) {
  const [modal, setModal] = useState<{ type: 'enquiry' | 'catalogue'; product?: Product; message?: string } | null>(null);
  return <EnquiryContext.Provider value={{ openEnquiry: (product, message) => setModal({ type: 'enquiry', product, message }), openCatalogue: () => setModal({ type: 'catalogue' }) }}>
    {children}
    {modal && <Modal label={modal.type === 'catalogue' ? 'Request Catalogue & Wholesale Pricing' : 'Send an enquiry'} onClose={() => setModal(null)} className="enquiry-modal">
      <div className="modal-intro">
        <Brand variant="hero" />
        <span className="eyebrow">LET'S CREATE SOMETHING BEAUTIFUL</span>
        <h2>{modal.type === 'catalogue' ? 'Request Catalogue & Wholesale Pricing' : 'A conversation, a new possibility.'}</h2>
        <p>{modal.type === 'catalogue' ? 'Request our catalogue and wholesale pricing, tailored to your business.' : 'Tell us a little about what you have in mind. We will take it from there.'}</p>
      </div>
      <Ornament />
      {modal.type === 'catalogue' ? <CatalogueForm onDone={() => setModal(null)} /> : <EnquiryForm product={modal.product} initialMessage={modal.message} onDone={() => setModal(null)} />}
    </Modal>}
  </EnquiryContext.Provider>;
}

export function useEnquiry() {
  const context = useContext(EnquiryContext);
  if (!context) throw new Error('useEnquiry must be used inside EnquiryProvider.');
  return context;
}

function FormResult({ result, onDone, onReset }: { result: SubmissionResult; onDone?: () => void; onReset: () => void }) {
  if (result.delivered || (result.stored && !result.local)) return <div className="form-success" role="status">
    <span className="success-icon"><Check size={28} strokeWidth={1.4} /></span>
    <h3>Thank you for reaching out.</h3>
    <p>Thank you! We'll get back to you within 24 hours.</p>
    {!result.delivered && <p className="form-note">Your request is safely in our inbox. The email notification is pending.</p>}
    <button className="button button-outline" onClick={onDone || onReset}>{onDone ? 'Back to exploring' : 'Send another enquiry'}<ArrowRight size={16} /></button>
  </div>;
  return <div className="form-delivery-error" role="alert">
    <Mail size={27} />
    <h3>Let's make sure we hear from you.</h3>
    <p>Your request was saved in this browser, but the email service could not confirm delivery. Please retry or write to us directly.</p>
    <div className="button-group"><button className="button button-primary" onClick={onReset}>Try again</button><a className="button button-outline" href="mailto:writemora@gmail.com">Write to Us<ArrowRight size={15} /></a></div>
  </div>;
}

export function EnquiryForm({ product, initialMessage = '', onDone }: { product?: Product; initialMessage?: string; onDone?: () => void }) {
  const { submitLead } = useStore();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<SubmissionResult | null>(null);
  const requestId = useRef(crypto.randomUUID());
  const [values, setValues] = useState({ name: '', businessName: '', city: '', phone: '', category: product?.category || '', message: initialMessage, website: '' });
  const change = (key: keyof typeof values, value: string) => setValues((current) => ({ ...current, [key]: value }));

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || values.website) return;
    if (!isValidPhone(values.phone)) { setError('Please enter a valid contact number with 10 to 15 digits.'); return; }
    if (!values.name.trim() || !values.city.trim() || !values.message.trim()) { setError('Please complete your name, city and requirement.'); return; }
    setBusy(true); setError('');
    try {
      setResult(await submitLead({ id: requestId.current, kind: 'enquiry', name: values.name.trim(), phone: values.phone.trim(), businessName: values.businessName.trim(), city: values.city.trim(), category: values.category, product: product?.name || '', message: values.message.trim() }));
    } catch (err) { setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.'); }
    finally { setBusy(false); }
  }

  const reset = () => {
    if (result?.delivered || (result?.stored && !result.local)) {
      requestId.current = crypto.randomUUID();
      setValues({ name: '', businessName: '', city: '', phone: '', category: '', message: '', website: '' });
    }
    setResult(null);
  };

  if (result) return <FormResult result={result} onDone={onDone} onReset={reset} />;

  return <form className="lead-form" onSubmit={submit}>
    {product && <div className="enquired-product"><CircleCheck size={16} /><span>Enquiring about <strong>{product.name}</strong>{product.productCode ? ` (${product.productCode})` : ''}</span></div>}
    <div className="form-grid">
      <label>Full Name <span>*</span><input name="name" autoComplete="name" placeholder="Your full name" required maxLength={100} value={values.name} onChange={(event) => change('name', event.target.value)} /></label>
      <label>Business Name<input name="businessName" autoComplete="organization" placeholder="Your business or company" maxLength={150} value={values.businessName} onChange={(event) => change('businessName', event.target.value)} /></label>
      <label>City <span>*</span><input name="city" autoComplete="address-level2" placeholder="Your city" required maxLength={100} value={values.city} onChange={(event) => change('city', event.target.value)} /></label>
      <label>Contact Number <span>*</span><input name="phone" type="tel" autoComplete="tel" placeholder="+91  Your contact number" required minLength={10} title="Enter a phone number with 10 to 15 digits" maxLength={20} value={values.phone} onChange={(event) => change('phone', event.target.value)} /></label>
      <label className="full-width">Product Category <span>*</span><select name="category" required value={values.category} onChange={(event) => change('category', event.target.value)}><option value="">Select a collection</option>{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}<option value="other">Other / Custom Requirements</option></select></label>
      <label className="full-width">Your Requirement <span>*</span><textarea name="message" placeholder="Tell us about the products, quantities or gifting ideas you have in mind..." rows={4} required maxLength={5000} value={values.message} onChange={(event) => change('message', event.target.value)} /></label>
    </div>
    <div className="honeypot" aria-hidden="true"><label>Website<input name="website" tabIndex={-1} autoComplete="off" value={values.website} onChange={(event) => change('website', event.target.value)} /></label></div>
    {error && <p className="form-error" role="alert">{error}</p>}
    <button className="button button-primary button-full" type="submit" disabled={busy}>{busy ? <><LoaderCircle size={17} className="spin" />Sending your enquiry...</> : <>Send Enquiry<ArrowRight size={17} /></>}</button>
    <p className="form-note"><ShieldCheck size={13} />Your details are only used to respond to your enquiry.</p>
  </form>;
}

function CatalogueForm({ onDone }: { onDone: () => void }) {
  const { submitLead } = useStore();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<SubmissionResult | null>(null);
  const requestId = useRef(crypto.randomUUID());
  const [values, setValues] = useState({ name: '', phone: '', city: '', businessType: '', website: '' });
  const change = (key: keyof typeof values, value: string) => setValues((current) => ({ ...current, [key]: value }));

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || values.website) return;
    if (!values.name.trim() || !isValidPhone(values.phone)) { setError('Please enter your full name and a valid contact number.'); return; }
    if (!values.city.trim()) { setError('Please enter your city so we can plan delivery and follow-up.'); return; }
    setBusy(true); setError('');
    try {
      setResult(await submitLead({ id: requestId.current, kind: 'catalogue', name: values.name.trim(), phone: values.phone.trim(), city: values.city.trim(), businessType: values.businessType }));
    } catch (err) { setError(err instanceof Error ? err.message : 'Unable to send. Please try again.'); }
    finally { setBusy(false); }
  }

  const reset = () => {
    requestId.current = crypto.randomUUID();
    setValues({ name: '', phone: '', city: '', businessType: '', website: '' });
    setResult(null);
  };

  if (result) return <FormResult result={result} onDone={onDone} onReset={reset} />;

  return <form className="lead-form catalogue-form" onSubmit={submit}>
    <h3 className="sr-only">Request Catalogue &amp; Wholesale Pricing</h3>
    <label>Full Name <span>*</span><input name="name" autoComplete="name" required placeholder="Your full name" maxLength={100} value={values.name} onChange={(event) => change('name', event.target.value)} /></label>
    <label>Contact Number <span>*</span><input name="phone" type="tel" autoComplete="tel" required placeholder="+91  Your contact number" minLength={10} maxLength={20} value={values.phone} onChange={(event) => change('phone', event.target.value)} /></label>
    <label>City <span>*</span><input name="city" autoComplete="address-level2" required maxLength={100} placeholder="Your city" value={values.city} onChange={(event) => change('city', event.target.value)} /></label>
    <label>Business Type <span>*</span><select name="businessType" value={values.businessType} onChange={(event) => change('businessType', event.target.value)} required><option value="">Tell us about your business</option>{businessTypes.map((type) => <option key={type}>{type}</option>)}</select></label>
    <div className="honeypot" aria-hidden="true"><label>Website<input name="website" autoComplete="off" tabIndex={-1} value={values.website} onChange={(event) => change('website', event.target.value)} /></label></div>
    {error && <p className="form-error" role="alert">{error}</p>}
    <button className="button button-primary button-full" type="submit" disabled={busy}>{busy ? <><LoaderCircle className="spin" size={17} />Sending your request...</> : <>Send My Request<ArrowRight size={17} /></>}</button>
    <p className="form-note"><ShieldCheck size={13} />Shared personally. No spam, just beautiful possibilities.</p>
  </form>;
}
