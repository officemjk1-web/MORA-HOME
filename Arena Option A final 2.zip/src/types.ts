export type CategoryId = 'kitchenware' | 'home-decor' | 'serveware' | 'pooja-products' | 'diwali-gifting' | 'occasion-gifting';

export interface ProductImage {
  src: string;
  alt: string;
  zoom?: number;
  x?: number;
  y?: number;
}

export interface Product {
  id: string;
  slug: string;
  productCode: string;
  name: string;
  category: CategoryId;
  tagline: string;
  description: string;
  material: string;
  dimensions: string;
  idealFor: string[];
  gifting: string;
  finish: string;
  orderTypes: string[];
  images: ProductImage[];
  status: 'Published' | 'Draft';
  createdAt: string;
}

export interface Lead {
  id: string;
  kind: 'enquiry' | 'catalogue';
  name: string;
  phone: string;
  businessName: string;
  city: string;
  category: string;
  businessType: string;
  product: string;
  message: string;
  createdAt: string;
  status: 'New' | 'Read';
  emailStatus: 'Pending' | 'Sent' | 'Failed';
}

export type LeadInput = Pick<Lead, 'id' | 'kind' | 'name' | 'phone'> & Partial<Pick<Lead, 'businessName' | 'city' | 'category' | 'businessType' | 'product' | 'message'>>;

export interface SubmissionResult {
  delivered: boolean;
  stored: boolean;
  local: boolean;
}