import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, BookOpen, Check, CheckCheck, ChevronRight, Download, Eye, EyeOff, FileDown, Info, LoaderCircle, LockKeyhole, LogOut, Mail, MessageSquare, Package, Pencil, Plus, RefreshCw, Search, Settings, ShieldCheck, Trash2, X } from 'lucide-react';
import { categories, categoryName } from '../data/catalogue';
import { isLiveMode, useStore } from '../lib/store';
import { dateLabel, downloadFile, exportCSV } from '../lib/utils';
import type { Lead, Product } from '../types';
import { Brand, Ornament } from '../components/Brand';
import { Modal } from '../components/Modal';
import { ProductEditor } from '../components/ProductEditor';
import { ProductImage } from '../components/ProductImage';

type AdminTab = 'products' | 'enquiries' | 'catalogue' | 'settings';

function AdminLogin() {
  const { login, loading } = useStore();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError('');
    try { await login(username.trim(), password); }
    catch (err) { setError(err instanceof Error ? err.message : 'Unable to sign in. Please try again.'); }
    finally { setBusy(false); }
  }

  return <section className="admin-login-section"><div className="admin-login-panel"><Brand variant="login" /><Ornament /><span className="eyebrow">THE MORA WORKSPACE</span><h1>A space for your craft.</h1><p>Sign in to manage your collection and conversations.</p><form className="lead-form" onSubmit={submit}>
    <label>Username<input autoComplete="username" required value={username} onChange={(event) => setUsername(event.target.value)} placeholder="Enter your username" /></label>
    <label>Password<div className="password-input"><input type={showPassword ? 'text' : 'password'} autoComplete="current-password" required value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter your password" /><button type="button" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword(!showPassword)}>{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button></div></label>
    {error && <p className="form-error" role="alert">{error}</p>}
    <button className="button button-gold button-full" type="submit" disabled={busy || loading}>{busy || loading ? <LoaderCircle className="spin" size={16} /> : <LockKeyhole size={16} />}{busy ? 'Signing in...' : 'Login'}<ArrowRight size={16} /></button>
  </form>{!isLiveMode && <details className="preview-access"><summary><Info size={14} />Local preview access</summary><p>This is a browser-only demonstration, not production authentication. Changes stay in this browser.</p><div><span>Username <code>admin</code></span><span>Password <code>MoraHome@2025</code></span></div><button className="text-link" onClick={() => { setUsername('admin'); setPassword('MoraHome@2025'); }}>Fill preview credentials<ArrowRight size={13} /></button></details>}<Link to="/" className="back-to-site">Return to MORA HOME<ArrowRight size={13} /></Link></div></section>;
}

function LeadDetail({ lead, onClose, onRead, onRetry, busy, error }: { lead: Lead; onClose: () => void; onRead: () => void; onRetry: () => void; busy: boolean; error: string }) {
  return <Modal label={`Enquiry from ${lead.name}`} onClose={onClose} className="lead-detail-modal">
    <span className="eyebrow">{lead.kind === 'catalogue' ? 'CATALOGUE REQUEST' : 'A NEW CONVERSATION'}</span><h2>{lead.name}</h2><span className="lead-date">Received {dateLabel(lead.createdAt)}</span><Ornament />
    <dl className="lead-details">
      <div><dt>Contact number</dt><dd><a href={`tel:${lead.phone.replace(/[^+0-9]/g, '')}`}>{lead.phone}</a></dd></div>
      {lead.businessName && <div><dt>Business</dt><dd>{lead.businessName}</dd></div>}
      {lead.city && <div><dt>City</dt><dd>{lead.city}</dd></div>}
      {lead.businessType && <div><dt>Business type</dt><dd>{lead.businessType}</dd></div>}
      {lead.category && <div><dt>Category</dt><dd>{categoryName(lead.category)}</dd></div>}
      {lead.product && <div><dt>Product</dt><dd>{lead.product}</dd></div>}
      <div><dt>Email notification</dt><dd>{lead.emailStatus === 'Sent' ? 'Accepted by email service' : lead.emailStatus === 'Failed' ? 'Not delivered - follow up directly' : 'Pending'}</dd></div>
    </dl>
    {lead.message && <div className="lead-message"><h3>Their requirement</h3><p>{lead.message}</p></div>}
    {error && <p className="form-error" role="alert">{error}</p>}
    <div className="button-group">
      <a href={`tel:${lead.phone.replace(/[^+0-9]/g, '')}`} className="button button-primary">Call {lead.name.split(' ')[0]}<ArrowRight size={15} /></a>
      {lead.status === 'New' && lead.kind === 'enquiry' && <button className="button button-outline" onClick={onRead} disabled={busy}><CheckCheck size={15} />Mark as Read</button>}
      {lead.emailStatus !== 'Sent' && <button className="button button-outline" onClick={onRetry} disabled={busy}>{busy ? <LoaderCircle size={15} className="spin" /> : <RefreshCw size={15} />}Retry Email</button>}
    </div>
  </Modal>;
}

function SettingsPanel({ notify }: { notify: (message: string) => void }) {
  const { products, leads, changePassword, importSamples } = useStore();
  const [passwords, setPasswords] = useState({ current: '', next: '', confirm: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [confirmImport, setConfirmImport] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError('');
    if (passwords.next !== passwords.confirm) { setError('Your new passwords do not match.'); return; }
    setBusy(true);
    try { await changePassword(passwords.current, passwords.next); setPasswords({ current: '', next: '', confirm: '' }); notify('Your local password has been updated.'); }
    catch (err) { setError(err instanceof Error ? err.message : 'Unable to update password.'); }
    finally { setBusy(false); }
  }
  async function importData() {
    setBusy(true); setError('');
    try { await importSamples(); notify('The sample collection is ready. Replace sample content with your verified products.'); setConfirmImport(false); }
    catch (err) { setError(err instanceof Error ? err.message : 'Import failed.'); }
    finally { setBusy(false); }
  }
  return <div className="admin-settings"><section className="settings-section"><div className="settings-title"><ShieldCheck size={22} strokeWidth={1.3} /><div><h2>Workspace &amp; security</h2><p>A clear picture of where your collection lives.</p></div></div><dl><div><dt>Environment</dt><dd>{isLiveMode ? 'Connected production API' : 'Local browser preview'}</dd></div><div><dt>Product &amp; lead storage</dt><dd>{isLiveMode ? 'Private server-side Netlify Blobs' : 'This browser only (localStorage)'}</dd></div><div><dt>Enquiry destination</dt><dd>writemora@gmail.com</dd></div></dl><p className="settings-notice">{isLiveMode ? 'Admin authentication is verified on the server. Set your admin credentials, session secret and Resend email credentials in your hosting environment. See README.md for deployment and verification steps.' : 'This preview demonstrates the complete workflow. It is not a secure multi-user backend. Public requests are relayed through FormSubmit, which requires the recipient to activate the first confirmation email. For shared data and server-verified login, deploy the included Netlify backend.'}</p></section>
    {!isLiveMode && <section className="settings-section"><div className="settings-title"><LockKeyhole size={22} strokeWidth={1.3} /><div><h2>Change local password</h2><p>Update the sign-in password for this browser's preview.</p></div></div><form className="lead-form password-settings" onSubmit={submit}><label>Current Password<input required type="password" autoComplete="current-password" value={passwords.current} onChange={(event) => setPasswords({ ...passwords, current: event.target.value })} /></label><div className="form-grid"><label>New Password<input required type="password" minLength={10} autoComplete="new-password" placeholder="At least 10 characters" value={passwords.next} onChange={(event) => setPasswords({ ...passwords, next: event.target.value })} /></label><label>Confirm New Password<input required type="password" minLength={10} autoComplete="new-password" value={passwords.confirm} onChange={(event) => setPasswords({ ...passwords, confirm: event.target.value })} /></label></div><button type="submit" className="button button-gold" disabled={busy}>{busy && <LoaderCircle className="spin" size={15} />}Update Password<ArrowRight size={15} /></button></form></section>}
    <section className="settings-section"><div className="settings-title"><FileDown size={22} strokeWidth={1.3} /><div><h2>Your data, at hand.</h2><p>Keep a copy of your collection and business enquiries.</p></div></div><div className="button-group"><button className="button button-outline" onClick={() => downloadFile('mora-home-products.json', new Blob([JSON.stringify(products, null, 2)], { type: 'application/json' }))}><Download size={15} />Export Products</button><button className="button button-outline" disabled={!leads.length} onClick={() => exportCSV('mora-home-all-enquiries.csv', leads.map((lead) => ({ Type: lead.kind, Name: lead.name, Phone: lead.phone, Business: lead.businessName || lead.businessType, City: lead.city, Category: categoryName(lead.category), Product: lead.product, Message: lead.message, Date: lead.createdAt, Status: lead.status })))}><Download size={15} />Export All Leads</button></div></section>
    <section className="settings-section"><div className="settings-title"><Package size={22} strokeWidth={1.3} /><div><h2>Explore with sample content</h2><p>Six illustrative products with generated photography and sample specifications.</p></div></div><p className="settings-notice">Sample products are for demonstration, not a verified inventory. Importing replaces only the six sample entries; your other products are preserved.</p><button className="button button-outline" onClick={() => setConfirmImport(true)}>Import Sample Collection<Plus size={15} /></button></section>
    {error && <p className="form-error" role="alert">{error}</p>}
    {confirmImport && <Modal label="Import sample collection" onClose={() => !busy && setConfirmImport(false)} className="confirmation-modal"><Package size={30} strokeWidth={1.3} /><h2>Bring in the sample collection?</h2><p>This adds six sample products. Existing products with the same sample IDs will be replaced. Your own products stay untouched.</p>{error && <p className="form-error" role="alert">{error}</p>}<div className="button-group"><button className="button button-outline" onClick={() => setConfirmImport(false)} disabled={busy}>Cancel</button><button className="button button-gold" onClick={importData} disabled={busy}>{busy ? <LoaderCircle className="spin" size={16} /> : <Plus size={16} />}Import Samples</button></div></Modal>}
  </div>;
}

function Dashboard() {
  const { products, leads, logout, saveProduct, deleteProduct, markRead, retryEmail, refresh, loading, error: storeError } = useStore();
  const [params, setParams] = useSearchParams();
  const tabValue = params.get('tab');
  const tab: AdminTab = ['products', 'enquiries', 'catalogue', 'settings'].includes(tabValue || '') ? tabValue as AdminTab : 'products';
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [editor, setEditor] = useState<{ product?: Product } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const notify = (message: string) => { setToast(message); if (timer.current) clearTimeout(timer.current); timer.current = setTimeout(() => setToast(''), 5000); };
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  useEffect(() => { setSearch(''); setCategory(''); setStatusFilter(''); setError(''); }, [tab]);

    const visibleProducts = products.filter((product) => (!category || product.category === category) && `${product.name} ${product.productCode}`.toLowerCase().includes(search.toLowerCase())).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const kind = tab === 'catalogue' ? 'catalogue' : 'enquiry';
  const visibleLeads = leads.filter((lead) => lead.kind === kind && (!statusFilter || lead.status === statusFilter) && `${lead.name} ${lead.businessName} ${lead.phone} ${lead.city}`.toLowerCase().includes(search.toLowerCase())).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const selectedLead = leads.find((lead) => lead.id === selectedLeadId);
  const newEnquiries = leads.filter((lead) => lead.kind === 'enquiry' && lead.status === 'New').length;
  const titles = { products: ['Your handcrafted collection.', 'Add, refine and share the pieces that define MORA HOME.'], enquiries: ['Conversations worth having.', 'Every enquiry is the beginning of a new partnership.'], catalogue: ['The next collection starts here.', 'Businesses who have asked to discover your craft.'], settings: ['A workspace that works for you.', 'Manage your account, connections and collection data.'] };

  async function act(action: () => Promise<void>, message: string) {
    setError(''); setBusy(true);
    try { await action(); if (message) notify(message); }
    catch (err) { setError(err instanceof Error ? err.message : 'The action could not be completed.'); }
    finally { setBusy(false); }
  }

  function exportLeads() {
    const filename = `mora-home-${tab}-${new Date().toISOString().slice(0, 10)}.csv`;
    if (tab === 'catalogue') {
      exportCSV(filename, visibleLeads.map((lead) => ({ Name: lead.name, Phone: lead.phone, 'Business Type': lead.businessType, City: lead.city, Date: lead.createdAt, 'Email Status': lead.emailStatus })));
    } else {
      exportCSV(filename, visibleLeads.map((lead) => ({ Name: lead.name, 'Business Name': lead.businessName, City: lead.city, Phone: lead.phone, Category: categoryName(lead.category), Product: lead.product, Message: lead.message, Date: lead.createdAt, Status: lead.status, 'Email Status': lead.emailStatus })));
    }
  }

  return <div className="admin-page container">
    {!isLiveMode && <div className="preview-notice"><Info size={15} /><span>Local preview workspace. Changes and enquiries are saved in this browser only.</span></div>}
    <div className="workspace-heading"><span className="eyebrow"><LockKeyhole size={12} />THE MORA WORKSPACE</span><div><Link to="/products" className="text-link">View your collection<ArrowRight size={13} /></Link><button className="text-link logout-button" onClick={() => void act(logout, '')}><LogOut size={14} />Sign out</button></div></div>
    <div className="admin-layout"><aside className="admin-sidebar"><nav aria-label="Workspace navigation">{[{ key: 'products', label: 'Products', icon: Package }, { key: 'enquiries', label: 'Enquiries', icon: MessageSquare }, { key: 'catalogue', label: 'Catalogue Requests', icon: BookOpen }, { key: 'settings', label: 'Settings', icon: Settings }].map(({ key, label, icon: Icon }) => <button key={key} className={tab === key ? 'active' : ''} onClick={() => setParams({ tab: key })}><Icon size={18} strokeWidth={1.5} /><span>{label}</span>{key === 'enquiries' && newEnquiries > 0 && <span className="inbox-count">{newEnquiries}</span>}<ChevronRight className="sidebar-chevron" size={13} /></button>)}</nav><div className="workspace-signature"><Brand variant="hero" /><p>Thoughtfully made.<br />Carefully managed.</p></div></aside>
      <div className="admin-main"><div className="admin-main-heading"><div><h1>{titles[tab][0]}</h1><p>{titles[tab][1]}</p></div>{tab === 'products' ? <button className="button button-gold" onClick={() => setEditor({})}><Plus size={17} />Add Product</button> : tab !== 'settings' && <button className="button button-outline" onClick={exportLeads} disabled={!visibleLeads.length}><Download size={15} />Export CSV</button>}</div>
        {(error || storeError) && <p className="form-error" role="alert">{error || storeError}</p>}
        {tab === 'settings' ? <SettingsPanel notify={notify} /> : <>
          <div className="admin-toolbar"><label className="admin-search"><Search size={17} /><input type="search" aria-label={tab === 'products' ? 'Search products' : 'Search enquiries'} placeholder={tab === 'products' ? 'Search your collection...' : 'Search by name, business or phone...'} value={search} onChange={(event) => setSearch(event.target.value)} /></label>{tab === 'products' ? <select aria-label="Filter by category" value={category} onChange={(event) => setCategory(event.target.value)}><option value="">All Categories</option>{categories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select> : tab === 'enquiries' && <select aria-label="Filter by enquiry status" value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option value="">All Enquiries</option><option value="New">New</option><option value="Read">Read</option></select>}<button className="icon-button" aria-label="Refresh workspace" title="Refresh" disabled={loading} onClick={() => void refresh()}><RefreshCw size={16} className={loading ? 'spin' : ''} /></button></div>
          {tab === 'products' ? <div className="admin-table-wrap"><table className="admin-table product-management-table"><thead><tr><th>Product</th><th>Category</th><th>Status</th><th>Date Added</th><th>Actions</th></tr></thead><tbody>{visibleProducts.map((product) => <tr key={product.id}><td><button className="table-product" onClick={() => setEditor({ product })}><ProductImage image={product.images[0]} /><span>{product.name}<small>{product.productCode || 'No code'} &middot; {product.material || 'Material not set'}</small></span></button></td><td>{categoryName(product.category)}</td><td><span className={`status-label ${product.status.toLowerCase()}`}>{product.status}</span></td><td className="table-date">{dateLabel(product.createdAt)}</td><td><div className="table-actions"><button className="icon-button" aria-label={`Edit ${product.name}`} title="Edit product" onClick={() => setEditor({ product })}><Pencil size={15} /></button><button className="icon-button" aria-label={`${product.status === 'Published' ? 'Hide' : 'Publish'} ${product.name}`} title={product.status === 'Published' ? 'Hide from collection' : 'Publish product'} disabled={busy} onClick={() => void act(() => saveProduct({ ...product, status: product.status === 'Published' ? 'Draft' : 'Published' }), product.status === 'Published' ? 'Product hidden from the collection.' : 'Product published to the collection.')}>{product.status === 'Published' ? <Eye size={16} /> : <EyeOff size={16} />}</button><button className="icon-button delete-action" aria-label={`Delete ${product.name}`} title="Delete product" onClick={() => setDeleteTarget(product)}><Trash2 size={15} /></button></div></td></tr>)}</tbody></table>{!visibleProducts.length && <div className="admin-empty"><Package size={35} strokeWidth={1.2} /><h3>{products.length ? 'No matching pieces.' : 'Your next collection begins here.'}</h3><p>{products.length ? 'Try another name or category.' : 'Add your first product to start sharing your craft.'}</p><button className="text-link" onClick={() => products.length ? (setSearch(''), setCategory('')) : setEditor({})}>{products.length ? 'Clear search' : 'Add a Product'}<ArrowRight size={14} /></button></div>}</div> : <div className="admin-table-wrap"><table className="admin-table enquiries-table"><thead><tr><th>Name</th>{tab === 'enquiries' && <><th>Business / City</th></>}<th>Phone</th><th>{tab === 'catalogue' ? 'Business Type' : 'Category / Requirement'}</th>{tab === 'catalogue' && <th>City</th>}<th>Date</th><th>{tab === 'enquiries' ? 'Status' : 'Email'}</th></tr></thead><tbody>{visibleLeads.map((lead) => <tr key={lead.id} className={lead.status === 'New' ? 'unread-row' : ''}><td><button className="table-name" onClick={() => setSelectedLeadId(lead.id)}>{lead.name}<span>View {tab === 'catalogue' ? 'request' : 'enquiry'}<ArrowRight size={11} /></span></button></td>{tab === 'enquiries' && <td>{lead.businessName || 'Not provided'}<small>{lead.city}</small></td>}<td><a href={`tel:${lead.phone.replace(/[^+0-9]/g, '')}`}>{lead.phone}</a></td><td>{tab === 'catalogue' ? lead.businessType : <>{categoryName(lead.category)}<small className="message-preview">{lead.product || lead.message}</small></>}</td>{tab === 'catalogue' && <td>{lead.city || 'Not provided'}</td>}<td className="table-date">{dateLabel(lead.createdAt)}</td><td>{tab === 'enquiries' ? lead.status === 'New' ? <button className="mark-read" disabled={busy} onClick={() => void act(() => markRead(lead.id), 'Enquiry marked as read.')}><span />Mark as Read</button> : <span className="read-label"><CheckCheck size={14} />Read</span> : <span className={`email-status ${lead.emailStatus.toLowerCase()}`}>{lead.emailStatus}</span>}</td></tr>)}</tbody></table>{!visibleLeads.length && <div className="admin-empty"><Mail size={36} strokeWidth={1.2} /><h3>{search || statusFilter ? 'No matching conversations.' : tab === 'catalogue' ? 'Your next partnership is on its way.' : 'A little quiet, for now.'}</h3><p>{search || statusFilter ? 'Try a different search or status.' : 'New submissions will appear here, ready for a personal follow-up.'}</p>{(search || statusFilter) && <button className="text-link" onClick={() => { setSearch(''); setStatusFilter(''); }}>Clear search<ArrowRight size={13} /></button>}</div>}</div>}
          <div className="admin-table-footer"><span>{tab === 'products' ? visibleProducts.length : visibleLeads.length} {tab === 'products' ? 'products' : tab === 'catalogue' ? 'requests' : 'enquiries'}</span><span>{isLiveMode ? 'Shared securely with your workspace' : 'Saved on this device'}</span></div>
        </>}
      </div>
    </div>
    {editor && <ProductEditor product={editor.product} onClose={() => setEditor(null)} onSaved={notify} />}
    {deleteTarget && <Modal label="Confirm product deletion" onClose={() => !busy && setDeleteTarget(null)} className="confirmation-modal"><Trash2 size={30} strokeWidth={1.2} /><h2>Remove this piece?</h2><p><strong>{deleteTarget.name}</strong> will be permanently removed from your collection. This action cannot be undone.</p>{error && <p className="form-error" role="alert">{error}</p>}<div className="button-group"><button className="button button-outline" disabled={busy} onClick={() => setDeleteTarget(null)}>Keep Product</button><button className="button button-primary" disabled={busy} onClick={() => void act(async () => { await deleteProduct(deleteTarget.id); setDeleteTarget(null); }, 'Product removed from the collection.')}>{busy ? <LoaderCircle className="spin" size={16} /> : <Trash2 size={15} />}Delete Product</button></div></Modal>}
    {selectedLead && <LeadDetail lead={selectedLead} onClose={() => { setSelectedLeadId(null); setError(''); }} onRead={() => void act(() => markRead(selectedLead.id), 'Enquiry marked as read.')} onRetry={() => void act(() => retryEmail(selectedLead.id), 'Email notification accepted by the email service.')} busy={busy} error={error} />}
    {toast && <div className="admin-toast" role="status"><Check size={17} /><span>{toast}</span><button className="icon-button" onClick={() => setToast('')} aria-label="Dismiss notification"><X size={16} /></button></div>}
  </div>;
}

export function Admin() {
  const { isAdmin } = useStore();
  return isAdmin ? <Dashboard /> : <AdminLogin />;
}