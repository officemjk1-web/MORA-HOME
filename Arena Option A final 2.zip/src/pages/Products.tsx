import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, BookOpen, ChevronDown, Factory, Flower2, RotateCcw, Search, SlidersHorizontal, Truck, X } from 'lucide-react';
import { categories, materialOptions, orderOptions, useOptions } from '../data/catalogue';
import { useStore } from '../lib/store';
import type { Product } from '../types';
import { Ornament } from '../components/Brand';
import { useEnquiry } from '../components/Enquiries';
import { Modal } from '../components/Modal';
import { ProductCard } from '../components/ProductCard';

type FilterKey = 'category' | 'material' | 'use' | 'order';
const materialMatch = (product: Product, material: string) => material === 'Antique Finish' ? /antique/i.test(product.finish) : material === 'Copper Finish' ? /copper/i.test(product.finish) : product.material === material;

export function Products() {
  const { products, loading, error, refresh } = useStore();
  const { openCatalogue, openEnquiry } = useEnquiry();
  const [params, setParams] = useSearchParams();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [expanded, setExpanded] = useState<Record<FilterKey, boolean>>({ category: true, material: true, use: true, order: false });
  const [search, setSearch] = useState('');
  const published = useMemo(() => products.filter((product) => product.status === 'Published'), [products]);
  const filters: Record<FilterKey, string[]> = { category: params.getAll('category'), material: params.getAll('material'), use: params.getAll('use'), order: params.getAll('order') };
  const sort = params.get('sort') || 'newest';
  const filterCount = Object.values(filters).reduce((total, values) => total + values.length, 0);

  const filtered = useMemo(() => {
    const list = published.filter((product) => {
      return (!filters.category.length || filters.category.includes(product.category)) &&
        (!filters.material.length || filters.material.some((material) => materialMatch(product, material))) &&
        (!filters.use.length || filters.use.some((use) => product.idealFor.includes(use))) &&
        (!filters.order.length || filters.order.some((order) => product.orderTypes.includes(order))) &&
        (!search || `${product.name} ${product.productCode} ${product.material} ${product.finish} ${product.idealFor.join(' ')}`.toLowerCase().includes(search.toLowerCase()));
    });
    return list.sort((a, b) => sort === 'az' ? a.name.localeCompare(b.name) : sort === 'category' ? a.category.localeCompare(b.category) || a.name.localeCompare(b.name) : new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [published, params, sort, search]);

  function toggleFilter(key: FilterKey, value: string) {
    const next = new URLSearchParams(params);
    const selected = next.getAll(key);
    next.delete(key);
    (selected.includes(value) ? selected.filter((item) => item !== value) : [...selected, value]).forEach((item) => next.append(key, item));
    setParams(next, { replace: true });
  }

  function selectCategory(category?: string) {
    const next = new URLSearchParams(params);
    next.delete('category');
    if (category) next.set('category', category);
    setParams(next, { replace: true });
  }

  function clearFilters() { setParams({}, { replace: true }); setSearch(''); }

  const groups: { key: FilterKey; title: string; options: { value: string; label: string; count: number }[] }[] = [
    { key: 'category', title: 'By Category', options: categories.map((category) => ({ value: category.id, label: category.name, count: published.filter((product) => product.category === category.id).length })) },
    { key: 'material', title: 'By Material', options: [...new Set([...materialOptions, ...published.map((product) => product.material).filter(Boolean)])].map((material) => ({ value: material, label: material, count: published.filter((product) => materialMatch(product, material)).length })) },
    { key: 'use', title: 'By Use / Ideal For', options: [...new Set([...useOptions, ...published.flatMap((product) => product.idealFor)])].map((use) => ({ value: use, label: use, count: published.filter((product) => product.idealFor.includes(use)).length })) },
    { key: 'order', title: 'By Order Type', options: [...new Set([...orderOptions, ...published.flatMap((product) => product.orderTypes)])].map((order) => ({ value: order, label: order, count: published.filter((product) => product.orderTypes.includes(order)).length })) },
  ];

  const renderSort = (id: string) => <label className="sort-control" htmlFor={id}>Sort by:<select id={id} value={sort} onChange={(event) => { const next = new URLSearchParams(params); next.set('sort', event.target.value); setParams(next, { replace: true }); }}><option value="newest">Newest</option><option value="az">A - Z</option><option value="category">Category</option></select></label>;

  const renderFilters = () => <>
    <div className="filter-title"><h2><SlidersHorizontal size={17} />Filters</h2><button onClick={clearFilters} disabled={!filterCount && !search}>Clear all</button></div>
    {groups.map((group) => <div className="filter-group" key={group.key}><button className="filter-group-toggle" onClick={() => setExpanded((current) => ({ ...current, [group.key]: !current[group.key] }))} aria-expanded={expanded[group.key]}>{group.title}<ChevronDown size={15} className={expanded[group.key] ? 'rotated' : ''} /></button>{expanded[group.key] && <div className="filter-options">{group.options.map((option) => <label key={option.value} className="filter-option"><input type="checkbox" checked={filters[group.key].includes(option.value)} onChange={() => toggleFilter(group.key, option.value)} /><span>{option.label}</span><span className="filter-count">{option.count}</span></label>)}</div>}</div>)}
    <div className="sidebar-help"><Flower2 size={27} strokeWidth={1} /><h3>Something in mind?</h3><p>Let's create a collection for your business.</p><button className="text-link" onClick={() => { setDrawerOpen(false); openEnquiry(); }}>Talk to us<ArrowRight size={14} /></button></div>
  </>;

  return <>
    <section className="collection-header"><div className="container"><div className="breadcrumb"><Link to="/">Home</Link><span>/</span><span>Our Collection</span></div><button className="button button-outline header-catalogue" onClick={openCatalogue}><BookOpen size={15} />Request Full Catalogue</button><div className="section-heading"><span className="eyebrow">THE MORA HOME COLLECTION</span><h1>Our Handcrafted Collection</h1><p>Wholesale-ready. Gifting-perfect. Moradabad-made.</p><div className="collection-trust"><span><Factory size={15} strokeWidth={1.3} />Direct Manufacturer</span><i /><span><Truck size={16} strokeWidth={1.3} />Pan-India Delivery</span></div></div><Ornament /></div></section>
    <div className="category-tabs"><div className="container" role="tablist" aria-label="Product categories"><button role="tab" aria-selected={!filters.category.length} className={!filters.category.length ? 'active' : ''} onClick={() => selectCategory()}>All Collections</button>{categories.map((category) => <button role="tab" key={category.id} aria-selected={filters.category.length === 1 && filters.category[0] === category.id} className={filters.category.includes(category.id) ? 'active' : ''} onClick={() => selectCategory(category.id)}>{category.shortName}</button>)}</div></div>
    <div className="container catalogue-layout">
      <aside className="filter-sidebar" aria-label="Filter products">{renderFilters()}</aside>
      <section className="collection-results" aria-label="Products">
        <div className="collection-toolbar"><div><span className="result-count" aria-live="polite">{loading ? 'Curating your collection...' : `${filtered.length} handcrafted ${filtered.length === 1 ? 'piece' : 'pieces'}`}</span><span className="code-hint">Know your code? Type <strong>HM-2001</strong> to find that piece instantly.</span></div><div className="toolbar-controls"><label className="product-search"><Search size={15} /><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search name or code..." aria-label="Search products by name or product code" /></label><span className="desktop-sort">{renderSort('sort-desktop')}</span><button className="button button-outline mobile-filter-button" onClick={() => setDrawerOpen(true)}><SlidersHorizontal size={15} />Filter &amp; Sort{filterCount > 0 && ` (${filterCount})`}</button></div></div>
        {filterCount > 0 && <div className="active-filter-row"><span>Refined by</span>{Object.entries(filters).flatMap(([key, values]) => values.map((value) => <button key={`${key}-${value}`} onClick={() => toggleFilter(key as FilterKey, value)}>{key === 'category' ? categories.find((category) => category.id === value)?.shortName || value : value}<X size={12} /></button>))}</div>}
        {error ? <div className="empty-state"><Flower2 size={47} strokeWidth={1} /><h2>Our collection will be right back.</h2><p>{error}</p><button className="button button-outline" onClick={refresh}>Try again<RotateCcw size={15} /></button></div> : loading ? <div className="product-grid">{[1, 2, 3].map((item) => <div className="product-skeleton" key={item}><div /><span /><span /></div>)}</div> : filtered.length ? <div className="product-grid">{filtered.map((product) => <ProductCard product={product} key={product.id} />)}</div> : <div className="empty-state"><Flower2 size={52} strokeWidth={1} /><h2>{published.length ? 'A little more to discover.' : 'Beautiful things are on their way.'}</h2><p>{published.length ? 'No pieces match these filters. Try a different combination, or let us help you find something special.' : "Our collection is being curated. Send us an enquiry and we'll share our full catalogue directly."}</p>{published.length ? <button className="button button-primary" onClick={clearFilters}>Clear All Filters<RotateCcw size={15} /></button> : <Link className="button button-primary" to="/#contact">Contact Us<ArrowRight size={15} /></Link>}</div>}
        {filtered.length > 0 && <div className="collection-end"><Ornament /><p>Every piece begins with a pair of skilled hands.</p><span>For custom designs, finishes and bulk requirements, <button onClick={() => openEnquiry()}>let's talk.</button></span></div>}
      </section>
    </div>
    {drawerOpen && <Modal label="Filter and sort products" onClose={() => setDrawerOpen(false)} className="filter-drawer"><div className="mobile-sort">{renderSort('sort-mobile')}</div>{renderFilters()}<div className="drawer-apply"><button className="button button-primary button-full" onClick={() => setDrawerOpen(false)}>Show {filtered.length} {filtered.length === 1 ? 'Product' : 'Products'}<ArrowRight size={16} /></button></div></Modal>}
  </>;
}