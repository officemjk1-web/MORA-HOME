import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowDown, ArrowRight, Factory, Gift, Hand, Handshake, HeartHandshake, Mail, MapPin, Package, Palette, Phone, ShoppingBag, Sparkles, Store, Truck } from 'lucide-react';
import { categories } from '../data/catalogue';
import { Brand, CategoryIcon, Ornament } from '../components/Brand';
import { EnquiryForm, useEnquiry } from '../components/Enquiries';
import { Reveal } from '../components/Reveal';

const partners = [
  { icon: Store, name: 'Wholesalers', text: 'Craft, at the right scale.' },
  { icon: ShoppingBag, name: 'Retailers & Stockists', text: 'Collections your customers love.' },
  { icon: Package, name: 'Bulk Buyers', text: 'More possibilities. Better value.' },
  { icon: Gift, name: 'Corporate Gifting', text: 'Gifts that reflect your brand.' },
  { icon: HeartHandshake, name: 'Return Gifting', text: 'A keepsake for every occasion.' },
  { icon: Sparkles, name: 'Occasion & Festive Gifting', text: 'Make every celebration special.' },
];

const promises = [
  { icon: Factory, title: 'Direct from the Manufacturer', description: 'No middlemen. Factory-direct partnerships from Moradabad.' },
  { icon: Hand, title: '100% Handcrafted Quality', description: 'Every piece shaped by skilled artisans in brass, iron and metal.' },
  { icon: Package, title: 'Bulk & Gifting Ready', description: 'Thoughtful custom packaging and branding for bulk orders.' },
  { icon: Truck, title: 'Pan-India Delivery', description: 'Reliable shipping, from our workshop to your doorstep.' },
  { icon: Handshake, title: 'A Trusted B2B Partner', description: 'Built around the needs of retailers, resellers and gifting businesses.' },
  { icon: Palette, title: 'Custom Orders Welcome', description: 'Your vision, our craft. Bespoke designs and private labels.' },
];

export function Home() {
  const { openEnquiry } = useEnquiry();
  const [storyExpanded, setStoryExpanded] = useState(false);

  return <>
    <section className="hero" aria-labelledby="hero-heading">
      <img className="hero-image" src="/images/mora-hero.jpg" alt="Handcrafted golden brass vases, serveware and traditional diyas arranged on ivory linen" fetchPriority="high" />
      <div className="hero-wash" />
      <div className="hero-pattern" />
      <div className="container hero-container">
        <div className="hero-content">
          <div className="hero-brand"><Brand variant="hero" /></div>
          <h1 id="hero-heading">Crafted in Moradabad.<br /><em>Made for your business.</em></h1>
          <p className="hero-description">Wholesale Supply <span /> Bulk Orders <span /> Corporate &amp; Festive Gifting</p>
          <div className="button-group hero-actions"><Link className="button button-outline" to="/products">Explore Our Products<ArrowRight size={16} /></Link><button className="button button-primary" onClick={() => openEnquiry()}>Send Enquiry<ArrowRight size={16} /></button></div>
        </div>
      </div>
      <a href="#partners" className="hero-scroll" aria-label="Discover who we work with"><ArrowDown size={17} strokeWidth={1.25} /></a>
    </section>

    <section className="partners-section section" id="partners">
      <div className="container"><Reveal>
        <div className="section-heading compact"><span className="eyebrow">YOUR BUSINESS. OUR CRAFT.</span><h2>Who We Work With</h2></div>
        <div className="partners-grid">{partners.map(({ icon: Icon, name, text }) => <div className="partner" key={name}><Icon size={30} strokeWidth={1.2} /><h3>{name}</h3><p>{text}</p></div>)}</div>
      </Reveal></div>
    </section>

    <section className="collections-section section" id="categories">
      <div className="container">
        <Reveal><div className="section-heading"><span className="eyebrow">TIMELESS BY TRADITION. THOUGHTFUL BY DESIGN.</span><h2>Our Product Range</h2><Ornament /><p>From everyday essentials to gifts that mean more. All crafted in Moradabad.</p></div></Reveal>
        <div className="category-grid">{categories.map((category, index) => <Reveal key={category.id} className="category-reveal"><Link className="category-card" to={`/products?category=${category.id}`}>
          <div className="category-image"><img src={category.image} alt={`Handcrafted ${category.name.toLowerCase()} collection by MORA HOME`} loading="lazy" width="600" height="600" /><span className="category-index">0{index + 1}</span></div>
          <div className="category-content"><CategoryIcon name={category.icon} size={22} /><h3>{category.name}</h3><p>{category.description}</p><span className="text-link">View Products<ArrowRight size={14} /></span></div>
        </Link></Reveal>)}</div>
        <div className="section-bottom-action"><Link to="/products" className="button button-outline">Explore the Complete Collection<ArrowRight size={17} /></Link></div>
      </div>
    </section>

    <section className="why-section section">
      <div className="container"><Reveal><div className="section-heading"><span className="eyebrow">MORE THAN A SUPPLIER. YOUR CRAFT PARTNER.</span><h2>Why Businesses Choose MORA HOME</h2><Ornament /></div><div className="promise-grid">{promises.map(({ icon: Icon, title, description }) => <div className="promise" key={title}><Icon size={33} strokeWidth={1.2} /><div><h3>{title}</h3><p>{description}</p></div></div>)}</div></Reveal></div>
    </section>

    <section className="about-section section" id="about">
      <div className="container"><Reveal className="about-layout">
        <div className="about-copy"><span className="eyebrow">WHO WE ARE</span><h2>Rooted in tradition.<br /><em>Crafted for tomorrow.</em></h2><Ornament />
          <p>MORA HOME is a Moradabad-based manufacturer and supplier of handcrafted brass, iron, and metal home products. Born from India's artisan capital, we work directly with skilled craftsmen to bring you premium kitchenware, home decor, serveware, pooja items, and gifting collections at wholesale-ready prices.</p>
          <p className="about-belief">We are your manufacturing partner,<br />not just a supplier.</p>
          {storyExpanded && <div className="expanded-story" id="brand-story"><p>From the first sketch to the final hand-finished detail, our work is guided by a simple belief: traditional craftsmanship belongs in everyday life. We pair time-honoured techniques with collections designed for the way people live and give today.</p><p>Whether you are building your retail range or creating a bespoke gifting programme, we work with you on product selection, finishes, packaging and delivery.</p></div>}
          <button className="button button-outline" onClick={() => setStoryExpanded(!storyExpanded)} aria-expanded={storyExpanded} aria-controls="brand-story">{storyExpanded ? 'A little less' : 'Learn More About Us'}<ArrowRight size={16} /></button>
        </div>
        <div className="about-photograph"><div className="artisan-image"><img src="/images/artisan.jpg" alt="A Moradabad artisan hand-engraving an intricate brass plate in a traditional workshop" loading="lazy" width="800" height="650" /></div><p><MapPin size={13} />MORADABAD, INDIA<span>WHERE EVERY PIECE HAS A STORY</span></p></div>
      </Reveal></div>
    </section>

    <section className="gifting-banner"><div className="gifting-pattern" /><div className="container"><Reveal className="gifting-content"><div><span className="eyebrow">THOUGHTFULLY GIVEN. BEAUTIFULLY REMEMBERED.</span><h2>Gifting that leaves an impression.</h2><p>From Diwali hampers to wedding return gifts, we bring your ideas to life<br className="desktop-break" /> with bespoke collections, custom packaging and your brand's personal touch.</p></div><button className="button button-light" onClick={() => openEnquiry(undefined, 'I would like a custom quote for corporate or festive gifting. ')}>Get a Custom Quote<ArrowRight size={17} /></button></Reveal></div></section>

    <section className="contact-section section" id="contact"><div className="container"><Reveal className="contact-layout">
      <div className="contact-copy"><span className="eyebrow">GOOD PARTNERSHIPS START WITH A CONVERSATION</span><h2>Let's build something<br /><em>beautiful together.</em></h2><p>Reach out for bulk enquiries, wholesale pricing,<br className="desktop-break" /> or custom gifting requirements.</p>
        <div className="contact-methods">
          <div className="contact-method"><Mail size={21} strokeWidth={1.25} /><div><span>FOR BUSINESS ENQUIRIES</span><a href="mailto:writemora@gmail.com">writemora@gmail.com</a></div><a className="button button-outline button-small" href="mailto:writemora@gmail.com">Write to Us<ArrowRight size={13} /></a></div>
          <div className="contact-method"><Mail size={21} strokeWidth={1.25} /><div><span>HAVE A QUESTION?</span><a href="mailto:asktomora@gmail.com">asktomora@gmail.com</a></div><a className="button button-outline button-small" href="mailto:asktomora@gmail.com">Ask MORA<ArrowRight size={13} /></a></div>
          <div className="contact-method"><Phone size={21} strokeWidth={1.25} /><div><span>A PERSONAL CONVERSATION</span><a href="tel:+918171246275">+91 8171246275</a></div><a className="button button-outline button-small" href="tel:+918171246275">Call Now<ArrowRight size={13} /></a></div>
        </div>
        <div className="contact-signature"><Brand /><span>From our hands, to your business.</span></div>
      </div>
      <div className="contact-form-wrap"><span className="eyebrow">TELL US WHAT YOU HAVE IN MIND</span><h3>Send us an enquiry</h3><EnquiryForm /></div>
    </Reveal></div></section>
  </>;
}