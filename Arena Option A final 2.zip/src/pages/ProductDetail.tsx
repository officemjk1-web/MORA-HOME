import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, CheckCircle2, ChevronLeft, ChevronRight, Factory, Gift, Hash, Leaf, Maximize2, Minus, Palette, Plus, RotateCcw, Ruler } from 'lucide-react';
import { categoryName } from '../data/catalogue';
import { useStore } from '../lib/store';
import { sanitizeRichText } from '../lib/utils';
import type { Product } from '../types';
import { Ornament } from '../components/Brand';
import { useEnquiry } from '../components/Enquiries';
import { Modal } from '../components/Modal';
import { ProductImage } from '../components/ProductImage';
import { ProductCard } from '../components/ProductCard';

function Lightbox({ product, initialIndex, onClose }: { product: Product; initialIndex: number; onClose: () => void }) {
  const [index, setIndex] = useState(initialIndex);
  const currentIndex = Math.min(index, product.images.length - 1);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const stage = useRef<HTMLDivElement>(null);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef({ distance: 0, zoom: 1, startX: 0, startY: 0, panX: 0, panY: 0, pinched: false });

  const changeImage = (direction: number) => {
    setIndex((current) => (Math.min(current, product.images.length - 1) + direction + product.images.length) % product.images.length);
    setZoom(1); setPan({ x: 0, y: 0 });
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'ArrowLeft') { event.preventDefault(); changeImage(-1); }
      if (event.key === 'ArrowRight') { event.preventDefault(); changeImage(1); }
      if (event.key === '+' || event.key === '=') setZoom((current) => Math.min(4, current + 0.5));
      if (event.key === '-') setZoom((current) => Math.max(1, current - 0.5));
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [product.images.length]);

  useEffect(() => {
    const element = stage.current;
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      setZoom((current) => Math.max(1, Math.min(4, current - event.deltaY * 0.003)));
    };
    element?.addEventListener('wheel', onWheel, { passive: false });
    return () => element?.removeEventListener('wheel', onWheel);
  }, []);

  useEffect(() => { if (zoom === 1) setPan({ x: 0, y: 0 }); }, [zoom]);

  function pointerDown(event: PointerEvent<HTMLDivElement>) {
    event.currentTarget.setPointerCapture(event.pointerId);
    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (pointers.current.size === 1) gesture.current = { distance: 0, zoom, startX: event.clientX, startY: event.clientY, panX: pan.x, panY: pan.y, pinched: false };
    if (pointers.current.size === 2) {
      const [a, b] = Array.from(pointers.current.values());
      gesture.current.distance = Math.hypot(a.x - b.x, a.y - b.y);
      gesture.current.zoom = zoom;
      gesture.current.pinched = true;
    }
  }

  function pointerMove(event: PointerEvent<HTMLDivElement>) {
    if (!pointers.current.has(event.pointerId)) return;
    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (pointers.current.size === 2) {
      const [a, b] = Array.from(pointers.current.values());
      setZoom(Math.max(1, Math.min(4, gesture.current.zoom * Math.hypot(a.x - b.x, a.y - b.y) / Math.max(1, gesture.current.distance))));
    } else if (zoom > 1) {
      const limit = 300 * zoom;
      setPan({ x: Math.max(-limit, Math.min(limit, gesture.current.panX + event.clientX - gesture.current.startX)), y: Math.max(-limit, Math.min(limit, gesture.current.panY + event.clientY - gesture.current.startY)) });
    }
  }

  function pointerUp(event: PointerEvent<HTMLDivElement>) {
    const delta = event.clientX - gesture.current.startX;
    if (event.type !== 'pointercancel' && !gesture.current.pinched && zoom === 1 && Math.abs(delta) > 60) changeImage(delta < 0 ? 1 : -1);
    pointers.current.delete(event.pointerId);
    if (pointers.current.size === 1) {
      const remaining = Array.from(pointers.current.values())[0];
      gesture.current = { distance: 0, zoom, startX: remaining.x, startY: remaining.y, panX: pan.x, panY: pan.y, pinched: true };
    }
  }

  return <Modal label={`${product.name} image gallery`} onClose={onClose} className="lightbox-modal">
    <div className="lightbox-heading"><h2>{product.name}</h2><span>{currentIndex + 1} / {product.images.length}</span></div>
    <div className="lightbox-stage" ref={stage} onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={pointerUp} onDoubleClick={() => { setZoom(zoom === 1 ? 2 : 1); setPan({ x: 0, y: 0 }); }} style={{ cursor: zoom > 1 ? 'grab' : 'zoom-in' }}>
      <div className="lightbox-image" style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` }}><ProductImage key={currentIndex} image={product.images[currentIndex]} eager /></div>
    </div>
    {product.images.length > 1 && <><button className="lightbox-prev icon-button" aria-label="Previous image" onClick={() => changeImage(-1)}><ChevronLeft size={32} strokeWidth={1} /></button><button className="lightbox-next icon-button" aria-label="Next image" onClick={() => changeImage(1)}><ChevronRight size={32} strokeWidth={1} /></button></>}
    <div className="lightbox-bottom"><span>{product.images[currentIndex]?.alt}</span><div className="lightbox-zoom"><button className="icon-button" aria-label="Zoom out" disabled={zoom <= 1} onClick={() => setZoom(Math.max(1, zoom - 0.5))}><Minus size={18} /></button><span aria-live="polite">{Math.round(zoom * 100)}%</span><button className="icon-button" aria-label="Zoom in" disabled={zoom >= 4} onClick={() => setZoom(Math.min(4, zoom + 0.5))}><Plus size={18} /></button><button className="icon-button" aria-label="Reset zoom" onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}><RotateCcw size={16} /></button></div><span className="lightbox-hint">Swipe to explore. Pinch to see the details.</span></div>
  </Modal>;
}

export function ProductDetail() {
  const { slug } = useParams();
  const { products, isAdmin, loading, error, refresh } = useStore();
  const { openEnquiry } = useEnquiry();
  const product = products.find((item) => item.slug === slug && (item.status === 'Published' || isAdmin));
  const [selected, setSelected] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  useEffect(() => { setSelected(0); setLightboxOpen(false); }, [slug]);
  useEffect(() => { setSelected((current) => Math.min(current, Math.max(0, (product?.images.length || 1) - 1))); }, [product?.images.length]);

  if (loading) return <div className="container detail-loading" role="status">Preparing the details...</div>;
  if (error) return <section className="not-found container"><h1>We'll be right back.</h1><p>{error}</p><button className="button button-outline" onClick={refresh}>Try again<RotateCcw size={15} /></button></section>;
  if (!product) return <section className="not-found container"><span className="eyebrow">A PIECE YET TO BE DISCOVERED</span><h1>This piece is not in our current collection.</h1><p>Explore our handcrafted range or enquire about a custom design.</p><Link to="/products" className="button button-primary"><ArrowLeft size={16} />Back to the collection</Link></section>;

  const specs = [
    { icon: Hash, label: 'Product Code', value: product.productCode }, { icon: Leaf, label: 'Material', value: product.material }, { icon: Ruler, label: 'Dimensions', value: product.dimensions },
    { icon: CheckCircle2, label: 'Ideal For', value: product.idealFor.join(', ') }, { icon: Gift, label: 'Gifting Suitable', value: product.gifting },
    { icon: Factory, label: 'Made In', value: 'Moradabad, India' }, { icon: Palette, label: 'Finish', value: product.finish },
  ];
  const related = products.filter((item) => item.id !== product.id && item.status === 'Published').sort((a, b) => Number(b.category === product.category) - Number(a.category === product.category)).slice(0, 3);

  return <div className="product-detail-page">
    <div className="container">
      <nav className="breadcrumb product-breadcrumb" aria-label="Breadcrumb"><Link to="/">Home</Link><ChevronRight size={11} /><Link to="/products">Products</Link><ChevronRight size={11} /><Link to={`/products?category=${product.category}`}>{categoryName(product.category)}</Link><ChevronRight size={11} /><span>{product.name}</span></nav>
      {product.status === 'Draft' && <div className="notice">Admin preview: this draft is not visible in the public collection.</div>}
      <div className="product-detail-layout">
        <div className="product-gallery">
          <button className="main-product-image" onClick={() => setLightboxOpen(true)} aria-label={`Open fullscreen gallery for ${product.name}`} disabled={!product.images.length}><ProductImage key={`${product.id}-${selected}`} image={product.images[selected]} eager /><span className="gallery-expand"><Maximize2 size={18} strokeWidth={1.3} /></span><span className="gallery-counter">{product.images.length ? selected + 1 : 0} / {product.images.length}</span></button>
          <div className="gallery-thumbnails" aria-label="Product photographs">{product.images.map((image, index) => <button key={`${image.src}-${index}`} className={index === selected ? 'selected' : ''} onClick={() => setSelected(index)} aria-label={`View image ${index + 1}: ${image.alt}`} aria-pressed={index === selected}><ProductImage image={image} /></button>)}</div>
          <p className="gallery-note">A closer look at the craft. Click to explore the details.</p>
        </div>
        <div className="product-detail-info"><span className="eyebrow">{categoryName(product.category).toUpperCase()}</span><h1>{product.name}</h1><p className="product-tagline">{product.tagline}</p><Ornament />
          <dl className="product-specifications">{specs.map(({ icon: Icon, label, value }) => <div key={label}><dt><Icon size={17} strokeWidth={1.3} />{label}</dt><dd>{value || 'Available on request'}</dd></div>)}</dl><Ornament />
          <div className="product-description rich-text" dangerouslySetInnerHTML={{ __html: sanitizeRichText(product.description) }} /><Ornament />
          <button className="button button-primary button-full detail-enquiry" onClick={() => openEnquiry(product)}>Send Enquiry for This Product<ArrowRight size={18} /></button><p className="pricing-note">No pricing shown publicly. Contact us for wholesale rates.</p>
          <details className="product-care"><summary>A note on handcrafted pieces<Plus size={15} /></summary><p>Subtle variations in finish are a natural part of handmade work. Clean with a soft, dry cloth and avoid abrasive cleaners. Contact us for material-specific care guidance and custom finish options.</p></details>
        </div>
      </div>
      {related.length > 0 && <section className="related-products"><div className="related-heading"><div><span className="eyebrow">MORE FROM OUR ARTISANS</span><h2>A few more beautiful possibilities.</h2></div><Link className="text-link" to="/products">View Collection<ArrowRight size={15} /></Link></div><div className="product-grid">{related.map((item) => <ProductCard product={item} key={item.id} />)}</div></section>}
    </div>
    {lightboxOpen && product.images.length > 0 && <Lightbox product={product} initialIndex={selected} onClose={() => setLightboxOpen(false)} />}
  </div>;
}