import { createHash, createHmac, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { getStore } from '@netlify/blobs';

const CATEGORY_IDS = ['kitchenware', 'home-decor', 'serveware', 'pooja-products', 'diwali-gifting', 'occasion-gifting'];
const BUSINESS_TYPES = ['Wholesaler', 'Retailer', 'Stockist', 'Corporate Gifting', 'Return Gifting', 'Occasion Gifting', 'Bulk Buyer'];
const SESSION_COOKIE = 'mora_admin';
const SESSION_SECONDS = 8 * 60 * 60;
const MAX_BODY_BYTES = 4.5 * 1024 * 1024;
const VALID_ID = /^[a-zA-Z0-9-]{1,100}$/;

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const json = (data, status = 200, extraHeaders = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...extraHeaders },
});

const digest = (value) => createHash('sha256').update(value).digest('hex');
const secret = () => process.env.ADMIN_SESSION_SECRET || '';
const store = () => getStore({ name: process.env.MORA_STORE || 'mora-home', consistency: 'strong' });

function requireConfiguration() {
  if (!process.env.ADMIN_USERNAME || (process.env.ADMIN_PASSWORD || '').length < 12 || secret().length < 32) {
    throw new HttpError(503, 'The private workspace is not configured. Set the server-side username, a password of at least 12 characters, and a session secret of at least 32 characters.');
  }
}

function constantEqual(a, b) {
  return timingSafeEqual(Buffer.from(digest(a)), Buffer.from(digest(b)));
}

function signSession() {
  const payload = Buffer.from(JSON.stringify({
    exp: Date.now() + SESSION_SECONDS * 1000,
    nonce: randomBytes(16).toString('hex'),
    version: digest(`${process.env.ADMIN_USERNAME}:${process.env.ADMIN_PASSWORD}`),
  })).toString('base64url');
  return `${payload}.${createHmac('sha256', secret()).update(payload).digest('base64url')}`;
}

function authenticated(request) {
  if (secret().length < 32 || !process.env.ADMIN_PASSWORD || !process.env.ADMIN_USERNAME) return false;
  const cookie = request.headers.get('cookie') || '';
  const token = cookie.split(';').map((part) => part.trim()).find((part) => part.startsWith(`${SESSION_COOKIE}=`))?.slice(SESSION_COOKIE.length + 1);
  if (!token || token.length > 1500) return false;
  const [payload, signature, extra] = token.split('.');
  if (!payload || !signature || extra) return false;
  const expected = createHmac('sha256', secret()).update(payload).digest('base64url');
  if (!constantEqual(signature, expected)) return false;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return Number.isFinite(data.exp) && data.exp > Date.now() && data.version === digest(`${process.env.ADMIN_USERNAME}:${process.env.ADMIN_PASSWORD}`);
  } catch { return false; }
}

function requireAdmin(request) {
  if (!authenticated(request)) throw new HttpError(401, 'Your session has expired. Please sign in again.');
}

function text(value, max, name, required = false) {
  if (typeof value !== 'string') {
    if (required) throw new HttpError(400, `${name} is required.`);
    return '';
  }
  const clean = value.trim();
  if (required && !clean) throw new HttpError(400, `${name} is required.`);
  if (clean.length > max) throw new HttpError(400, `${name} is too long.`);
  return clean;
}

function stringArray(value, label) {
  if (!Array.isArray(value) || value.length > 30) throw new HttpError(400, `Invalid ${label}.`);
  return [...new Set(value.map((item) => text(item, 150, label, true)))];
}

async function body(request) {
  if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) throw new HttpError(415, 'Please submit JSON data.');
  if (Number(request.headers.get('content-length') || 0) > MAX_BODY_BYTES) throw new HttpError(413, 'This request is too large. Please use smaller photographs.');
  const raw = await request.text();
  if (Buffer.byteLength(raw) > MAX_BODY_BYTES) throw new HttpError(413, 'This request is too large. Please use smaller photographs.');
  try {
    const result = JSON.parse(raw);
    if (!result || typeof result !== 'object' || Array.isArray(result)) throw new Error('Invalid object');
    return result;
  } catch { throw new HttpError(400, 'The submitted data could not be read.'); }
}

async function listRecords(prefix) {
  const storage = store();
  const result = await storage.list({ prefix });
  const records = await Promise.all(result.blobs.map(({ key }) => storage.get(key, { type: 'json' })));
  return records.filter(Boolean);
}

// Strongly consistent conditional writes prevent concurrent requests bypassing the limits.
async function rateLimit(context, scope, maximum, interval) {
  const key = `limits/${scope}/${digest(`${secret()}:${context.ip || 'unknown'}`).slice(0, 40)}`;
  const storage = store();
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const current = await storage.getWithMetadata(key, { type: 'json' });
    const active = current && current.data.resetAt > Date.now() ? current.data : { count: 0, resetAt: Date.now() + interval };
    if (active.count >= maximum) throw new HttpError(429, 'Too many attempts. Please wait a little before trying again.');
    const result = await storage.setJSON(key, { count: active.count + 1, resetAt: active.resetAt }, current ? { onlyIfMatch: current.etag } : { onlyIfNew: true });
    if (result.modified) return;
  }
  throw new HttpError(429, 'Please wait a moment before trying again.');
}

function verifyOrigin(request) {
  if (request.method === 'GET' || request.method === 'HEAD') return;
  const origin = request.headers.get('origin');
  const allowed = new Set([new URL(request.url).origin]);
  if (process.env.SITE_ORIGIN) allowed.add(process.env.SITE_ORIGIN.replace(/\/$/, ''));
  if (origin && !allowed.has(origin)) throw new HttpError(403, 'This request did not originate from the MORA HOME website.');
}

async function storeImages(images, name) {
  if (!Array.isArray(images) || images.length > 8) throw new HttpError(400, 'Each product supports up to 8 photographs.');
  return Promise.all(images.map(async (image, index) => {
    if (!image || typeof image.src !== 'string') throw new HttpError(400, 'Invalid product photograph.');
    let src = image.src;
    if (src.startsWith('data:')) {
      const match = src.match(/^data:(image\/(?:jpeg|png|webp));base64,([a-zA-Z0-9+/=]+)$/);
      if (!match) throw new HttpError(400, 'Only JPG, PNG and WebP photos are supported.');
      const bytes = Buffer.from(match[2], 'base64');
      if (bytes.length > 1024 * 1024 || bytes.length < 20) throw new HttpError(400, 'An optimised photograph must be smaller than 1 MB.');
      const jpeg = bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
      const png = bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
      const webp = bytes.subarray(0, 4).toString() === 'RIFF' && bytes.subarray(8, 12).toString() === 'WEBP';
      if (!(match[1] === 'image/jpeg' && jpeg || match[1] === 'image/png' && png || match[1] === 'image/webp' && webp)) throw new HttpError(400, 'The photograph format could not be verified.');
      const id = randomUUID();
      await store().set(`images/${id}`, new Blob([bytes], { type: match[1] }), { metadata: { contentType: match[1] } });
      src = `/api/image/${id}`;
    } else if (!/^\/images\/[a-zA-Z0-9_-]+\.(?:jpg|jpeg|png|webp)$/.test(src) && !/^\/api\/image\/[a-zA-Z0-9-]+$/.test(src)) {
      throw new HttpError(400, 'Please upload product photographs through the photo uploader.');
    }
    return {
      src, alt: text(image.alt, 250, 'Image description') || `${name} - image ${index + 1}`,
      zoom: Math.min(3, Math.max(1, Number(image.zoom) || 1)),
      x: Math.min(100, Math.max(0, Number.isFinite(Number(image.x)) ? Number(image.x) : 50)),
      y: Math.min(100, Math.max(0, Number.isFinite(Number(image.y)) ? Number(image.y) : 50)),
    };
  }));
}

async function saveProduct(request, id) {
  requireAdmin(request);
  const input = await body(request);
  const name = text(input.name, 150, 'Product name', true);
  const productCode = text(input.productCode, 20, 'Product code', true).toUpperCase();
  if (!/^HM-\d{4,6}$/.test(productCode)) throw new HttpError(400, 'Product codes must use the HM-0000 format, for example HM-2001.');
  const slug = text(input.slug, 180, 'Product URL', true);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) throw new HttpError(400, 'The product URL must contain lowercase letters, numbers and hyphens.');
  if (!CATEGORY_IDS.includes(input.category)) throw new HttpError(400, 'Please choose a valid category.');
  if (!['Published', 'Draft'].includes(input.status)) throw new HttpError(400, 'Please choose a valid product status.');
  const description = text(input.description, 15000, 'Description');
  if (input.status === 'Published' && (!input.images?.length || !description.replace(/<[^>]*>/g, '').trim())) throw new HttpError(400, 'Published products need at least one photograph and a description.');
  const existing = await store().get(`products/${id}`, { type: 'json' });
  const records = await listRecords('products/');
  if (records.some((record) => record.id !== id && (record.slug === slug || record.productCode === productCode))) throw new HttpError(409, 'Another product already has this URL or product code. Please use a distinct name and code.');
  const product = {
    id, slug, productCode, name, category: input.category, status: input.status, description,
    tagline: text(input.tagline, 180, 'Tagline'), material: text(input.material, 100, 'Material'),
    dimensions: text(input.dimensions, 180, 'Dimensions'), gifting: text(input.gifting, 180, 'Gifting suitability'),
    finish: text(input.finish, 120, 'Finish'), idealFor: stringArray(input.idealFor || [], 'Ideal for'),
    orderTypes: stringArray(input.orderTypes || [], 'Order types'),
    images: await storeImages(input.images || [], name),
    createdAt: existing?.createdAt || (typeof input.createdAt === 'string' && Number.isFinite(Date.parse(input.createdAt)) ? new Date(input.createdAt).toISOString() : new Date().toISOString()),
  };
  await store().setJSON(`products/${id}`, product);
  return json({ product });
}

function validateLead(input) {
  if (!['catalogue', 'enquiry'].includes(input.kind)) throw new HttpError(400, 'Invalid request type.');
  if (!VALID_ID.test(input.id || '')) throw new HttpError(400, 'Invalid request identifier.');
  const name = text(input.name, 100, 'Full name', true);
  const phone = text(input.phone, 20, 'Contact number', true);
  if (!/^\+?[0-9 ()-]{10,20}$/.test(phone) || !/^[0-9]{10,15}$/.test(phone.replace(/\D/g, ''))) throw new HttpError(400, 'Please enter a valid contact number.');
  const lead = {
    id: input.id, kind: input.kind, name, phone,
    businessName: text(input.businessName, 150, 'Business name'), city: text(input.city, 100, 'City', true),
    category: text(input.category, 100, 'Product category', input.kind === 'enquiry'),
    businessType: text(input.businessType, 100, 'Business type', input.kind === 'catalogue'),
    product: text(input.product, 150, 'Product'), message: text(input.message, 5000, 'Requirement', input.kind === 'enquiry'),
    createdAt: new Date().toISOString(), status: 'New', emailStatus: 'Pending',
  };
  if (lead.kind === 'catalogue' && !BUSINESS_TYPES.includes(lead.businessType)) throw new HttpError(400, 'Please choose a valid business type.');
  if (lead.kind === 'enquiry' && ![...CATEGORY_IDS, 'other'].includes(lead.category)) throw new HttpError(400, 'Please choose a valid category.');
  return lead;
}

async function sendEmail(lead) {
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM) return false;
  const fields = [
    ['Request', lead.kind === 'catalogue' ? 'Wholesale catalogue & pricing' : 'Business enquiry'],
    ['Full name', lead.name], ['Contact number', lead.phone], ['Business', lead.businessName || lead.businessType],
    ['City', lead.city], ['Category', lead.category], ['Product', lead.product],
    ['Requirement', lead.message || 'Please share your catalogue and wholesale pricing.'], ['Received', lead.createdAt],
  ];
  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST', signal: AbortSignal.timeout(10000),
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json', 'Idempotency-Key': `mora-${lead.id}` },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM, to: ['writemora@gmail.com'],
        subject: `MORA HOME | ${lead.kind === 'catalogue' ? 'Catalogue request' : 'New enquiry'} | ${lead.name}`,
        text: ['MORA HOME', '', ...fields.filter(([, value]) => value).map(([key, value]) => `${key}: ${value}`), '', 'Manage this conversation in your private MORA HOME workspace.'].join('\n'),
      }),
    });
    const data = await response.json();
    return response.ok && Boolean(data.id);
  } catch { return false; }
}

async function submitLead(request, context) {
  await rateLimit(context, 'leads', 10, 60 * 60 * 1000);
  const input = await body(request);
  const lead = validateLead(input);
  const key = `leads/${lead.id}`;
  const existing = await store().get(key, { type: 'json' });
  if (existing) {
    if (existing.name !== lead.name || existing.phone !== lead.phone || existing.kind !== lead.kind) throw new HttpError(409, 'This request identifier has already been used. Please start a new request.');
    if (existing.emailStatus === 'Sent') return json({ delivered: true, stored: true, local: false });
    lead.createdAt = existing.createdAt;
    lead.status = existing.status;
  }
  await store().setJSON(key, lead);
  const delivered = await sendEmail(lead);
  lead.emailStatus = delivered ? 'Sent' : 'Failed';
  await store().setJSON(key, lead);
  return json({ delivered, stored: true, local: false }, existing ? 200 : 201);
}

export default async function handler(request, context) {
  try {
    verifyOrigin(request);
    const url = new URL(request.url);
    const path = url.pathname.replace(/^\/(?:\.netlify\/functions\/api|api)(?:\/|$)/, '/').replace(/\/$/, '') || '/';
    const parts = path.split('/').filter(Boolean);
    const method = request.method;

    if (path === '/session' && method === 'GET') return json({ authenticated: authenticated(request) });
    if (path === '/status' && method === 'GET') return json({ mode: 'live', emailConfigured: Boolean(process.env.RESEND_API_KEY && process.env.EMAIL_FROM) });

    if (path === '/login' && method === 'POST') {
      requireConfiguration();
      await rateLimit(context, 'login', 8, 15 * 60 * 1000);
      const input = await body(request);
      const username = text(input.username, 100, 'Username', true);
      if (typeof input.password !== 'string' || !input.password.length || input.password.length > 300) throw new HttpError(400, 'Please enter your password.');
      const password = input.password;
      if (!constantEqual(username, process.env.ADMIN_USERNAME) || !constantEqual(password, process.env.ADMIN_PASSWORD)) throw new HttpError(401, 'The username or password is incorrect.');
      return json({ authenticated: true }, 200, { 'Set-Cookie': `${SESSION_COOKIE}=${signSession()}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_SECONDS}` });
    }

    if (path === '/logout' && method === 'POST') return json({ authenticated: false }, 200, { 'Set-Cookie': `${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0` });

    if (path === '/products' && method === 'GET') {
      const all = url.searchParams.get('scope') === 'all';
      if (all) requireAdmin(request);
      const records = await listRecords('products/');
      return json({ products: records.filter((product) => all || product.status === 'Published').sort((a, b) => b.createdAt.localeCompare(a.createdAt)) });
    }

    if (parts[0] === 'products' && parts.length === 2 && VALID_ID.test(parts[1])) {
      if (method === 'PUT') return await saveProduct(request, parts[1]);
      if (method === 'DELETE') {
        requireAdmin(request);
        await store().delete(`products/${parts[1]}`);
        return json({ deleted: true });
      }
    }

    if (parts[0] === 'image' && parts.length === 2 && VALID_ID.test(parts[1]) && method === 'GET') {
      const image = await store().getWithMetadata(`images/${parts[1]}`, { type: 'arrayBuffer' });
      if (!image) throw new HttpError(404, 'This photograph could not be found.');
      return new Response(image.data, { headers: { 'Content-Type': image.metadata.contentType || 'image/jpeg', 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff' } });
    }

    if (path === '/leads' && method === 'POST') return await submitLead(request, context);
    if (path === '/leads' && method === 'GET') {
      requireAdmin(request);
      return json({ leads: (await listRecords('leads/')).sort((a, b) => b.createdAt.localeCompare(a.createdAt)) });
    }

    if (parts[0] === 'leads' && parts.length === 2 && VALID_ID.test(parts[1]) && method === 'PATCH') {
      requireAdmin(request);
      const input = await body(request);
      if (input.status !== 'Read') throw new HttpError(400, 'Unsupported enquiry status.');
      const key = `leads/${parts[1]}`;
      const lead = await store().get(key, { type: 'json' });
      if (!lead) throw new HttpError(404, 'This enquiry could not be found.');
      lead.status = 'Read';
      await store().setJSON(key, lead);
      return json({ lead });
    }

    if (parts[0] === 'retry-email' && parts.length === 2 && VALID_ID.test(parts[1]) && method === 'POST') {
      requireAdmin(request);
      await rateLimit(context, 'retry-email', 30, 60 * 60 * 1000);
      const key = `leads/${parts[1]}`;
      const lead = await store().get(key, { type: 'json' });
      if (!lead) throw new HttpError(404, 'This enquiry could not be found.');
      if (lead.emailStatus === 'Sent') return json({ delivered: true });
      const delivered = await sendEmail(lead);
      lead.emailStatus = delivered ? 'Sent' : 'Failed';
      await store().setJSON(key, lead);
      return json({ delivered });
    }

    return json({ error: 'This API endpoint was not found.' }, 404);
  } catch (error) {
    if (error instanceof HttpError) return json({ error: error.message }, error.status);
    console.error('MORA API error:', error instanceof Error ? error.message : 'Unknown error');
    return json({ error: 'The request could not be completed. Please try again or contact writemora@gmail.com.' }, 500);
  }
}